<?php
	ob_start();
	session_start();
	require_once 'config/connect.php';
	if(!isset($_SESSION['customer']) & empty($_SESSION['customer'])){
		header('location: login.php');
	}
include 'inc/header.php';

$uid = $_SESSION['customerid'];
if (isset($_SESSION['cart'])){
$cart = $_SESSION['cart'];
} 

if(isset($_POST) & !empty($_POST)){
		$cancel = filter_var($_POST['cancel'], FILTER_SANITIZE_STRING);
		$id = filter_var($_POST['orderid'], FILTER_SANITIZE_NUMBER_INT);

			$cansql = "INSERT INTO ordertracking (orderid, status, message) VALUES ('$id', 'Cancelled', '$cancel')";
			$canres = mysqli_query($connection, $cansql) or die(mysqli_error($connection));
			if($canres){
				$ordupd = "UPDATE orders SET orderstatus='Annulé' WHERE id=$id";
				if(mysqli_query($connection, $ordupd)){
					header('location: my-account.php');
				}
			}
}

$sql = "SELECT * FROM usersmeta WHERE uid=$uid";
$res = mysqli_query($connection, $sql);
$r = mysqli_fetch_assoc($res);
?>
<section class="collierH">


<form method="post">
<table class="cart-table account-table table ">
<thead>
  <tr>
    <th>commande</th>
    <th>Date</th>
    <th>Status</th>
    <th>Methode de payement</th>
    <th>Total</th>

  </tr>
</thead>
<tbody>

<?php
  if(isset($_GET['id']) & !empty($_GET['id'])){
    $oid = $_GET['id'];
  }else{
    header('location: my-account.php');
  }
  $ordsql = "SELECT * FROM orders WHERE id='$oid'";
  $ordres = mysqli_query($connection, $ordsql);
  while($ordr = mysqli_fetch_assoc($ordres)){
?>
  <tr>
    <td>
      <?php echo $ordr['id']; ?>
    </td>
    <td>
      <?php echo $ordr['timestamp']; ?>
    </td>
    <td class="text-success"> <strong>
      <?php echo $ordr['orderstatus']; ?>
</strong>
		</td>
    <td>
      <?php echo $ordr['paymentmode']; ?>
    </td>
    <td>
      <?php echo $ordr['totalprice']; ?> DT
    </td>
  </tr>
<?php } ?>
</tbody>
</table>
<h5>Raison :</h5>
<textarea class="form-control" name="cancel" cols="10"> </textarea>

<input type="hidden" name="orderid" value="<?php echo $_GET['id']; ?>">
<div class="space30"></div>
<div class="row my-3">
    <div class="col-3"></div>
  <div class="col-3">


  <input style="float:right;" class="btn btn-outline-dark " onclick="goBack()" value="Revenir">
  </div>

<div class="col-3">


<input type="submit" class="btn btn-dark " value="Annuler Commande">
</div>

</div>
</form>
</section>
<?php include 'inc/footer.php' ?>
<script>
function goBack() {
  window.history.back();
}

</script>
