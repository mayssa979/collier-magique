This directory provides examples for specific use cases. Please [open an issue](https://github.com/sendgrid/php-http-client/issues) or make a pull request for any use cases you would like us to document here. Thank you!

# Table of Contents
* [Docker](docker.md)
