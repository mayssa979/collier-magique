<?php 
require 'config/connect.php';

$pwd=$_POST['password'];
$email=$_POST['email'];
$sql="UPDATE users SET password='$pwd' WHERE email='$email'";
$res=mysqli_query($connection,$sql);

?>



<?php header("location: home.php"); ?>