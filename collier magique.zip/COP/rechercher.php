<?php 
session_start();
include 'admin/connect3.php';
require_once 'config/connect.php';
include 'inc/header.php';
if (isset($_POST['rechercher'])){
    $rech=$_POST['rechercher'];
}
?>
<br>
<br>
<!--<div class="overlay2">
 
 
  <div class="row py-5">-->
    <div class="container">
      <div class="row">
      <?php
  $sql1="SELECT id FROM products where  name LIKE '%$rech%'";
  $result = mysqli_query($connection, $sql1);
  while($row=mysqli_fetch_assoc($result)){
      
      $id=$row['id'];
      
      $sql = "SELECT * FROM products WHERE id='$id' ";
   
    $res = mysqli_query($connection, $sql);
  
    ?>
      <?php if (isset($res)){ 
      while($r = mysqli_fetch_assoc($res)){ ?>

            <div class="col-lg-3 produitdiv">
              <div class="shadow">

              <div class="overlay">
              <a href="single.php?id=<?php echo $r['id']; ?>">
                 <img class="d-block w-100 prod-pic" src="<?php echo $r['thumb']; ?>" alt="second pic">
              </a>
                
                </div>
                <div class="down-div">
            <p class="title-buy text-center">
              <?php echo $r['name']; ?>            </p>
            <p class="price-buy text-center">
              <?php echo $r['price']; ?> DT
            </p>
            <a href="addtocart.php?id=<?php echo $r['id']; ?>" class="checkoutlink">
              <button type="button" class="btn  btn-block my-2 btn-color ">Ajouter au panier</button>
            </a>
                </div>
</div>


        </div>
            <?php  }?>

       <!--</div>
      
     </div> -->
      
      <?php } } ?>    

      
<?php  
include 'inc/footer.php';
?>