<?php
	ob_start();
	session_start();
	require_once 'config/connect.php';
	if(!isset($_SESSION['customer']) & empty($_SESSION['customer'])){
		header('location: login.php');
	}
include 'inc/header.php';
$uid = $_SESSION['customerid'];
 $cart = $_SESSION['cart'];

if(isset($_POST) & !empty($_POST)){
	if($_POST['agree'] == true){
		$country = filter_var($_POST['country'], FILTER_SANITIZE_STRING);
		$fname = filter_var($_POST['fname'], FILTER_SANITIZE_STRING);
		$lname = filter_var($_POST['lname'], FILTER_SANITIZE_STRING);
		$company = filter_var($_POST['company'], FILTER_SANITIZE_STRING);
		$address1 = filter_var($_POST['address1'], FILTER_SANITIZE_STRING);
		$city = filter_var($_POST['city'], FILTER_SANITIZE_STRING);
		$state = filter_var($_POST['state'], FILTER_SANITIZE_STRING);
		$phone = filter_var($_POST['phone'], FILTER_SANITIZE_NUMBER_INT);
		$payment = filter_var($_POST['payment'], FILTER_SANITIZE_STRING);
		$zip = filter_var($_POST['zipcode'], FILTER_SANITIZE_NUMBER_INT);

		$sql = "SELECT * FROM usersmeta WHERE uid=$uid";
		$res = mysqli_query($connection, $sql);
		$r = mysqli_fetch_assoc($res);
		$count = mysqli_num_rows($res);
		if($count == 1){

			$usql = "UPDATE usersmeta SET country='$country', firstname='$fname', lastname='$lname', address1='$address1', address2='$address2', city='$city', state='$state',  zip='$zip', company='$company', mobile='$phone' WHERE uid=$uid";
			$ures = mysqli_query($connection, $usql) or die(mysqli_error($connection));
			if($ures){

				$total = 0;
				foreach ($cart as $key => $value) {

					$ordsql = "SELECT * FROM products WHERE id=$key";
					$ordres = mysqli_query($connection, $ordsql);
					$ordr = mysqli_fetch_assoc($ordres);

					$total = $total + ($ordr['price']*$value['quantity']);
				}

				echo $iosql = "INSERT INTO orders (uid, totalprice, orderstatus, paymentmode) VALUES ('$uid', '$total', 'Commande ajoutée', '$payment')";
				$iores = mysqli_query($connection, $iosql) or die(mysqli_error($connection));
				if($iores){

					$orderid = mysqli_insert_id($connection);
					foreach ($cart as $key => $value) {

						$ordsql = "SELECT * FROM products WHERE id=$key";
						$ordres = mysqli_query($connection, $ordsql);
						$ordr = mysqli_fetch_assoc($ordres);

						$pid = $ordr['id'];
						$productprice = $ordr['price'];
						$quantity = $value['quantity'];


						$orditmsql = "INSERT INTO orderitems (pid, orderid, productprice, pquantity) VALUES ('$pid', '$orderid', '$productprice', '$quantity')";
						$orditmres = mysqli_query($connection, $orditmsql) or die(mysqli_error($connection));


					}
				}
				unset($_SESSION['cart']);
				header("location: my-account.php");
			}
		}else{

			$isql = "INSERT INTO usersmeta (country, firstname, lastname, address1, address2, city, state, zip, company, mobile, uid) VALUES ('$country', '$fname', '$lname', '$address1', '$address2', '$city', '$state', '$zip', '$company', '$phone', '$uid')";
			$ires = mysqli_query($connection, $isql) or die(mysqli_error($connection));
			if($ires){

				$total = 0;
				foreach ($cart as $key => $value) {

					$ordsql = "SELECT * FROM products WHERE id=$key";
					$ordres = mysqli_query($connection, $ordsql);
					$ordr = mysqli_fetch_assoc($ordres);

					$total = $total + ($ordr['price']*$value['quantity']);
				}

				echo $iosql = "INSERT INTO orders (uid, totalprice, orderstatus, paymentmode) VALUES ('$uid', '$total', 'Commande ajouté', '$payment')";
				$iores = mysqli_query($connection, $iosql) or die(mysqli_error($connection));
				if($iores){

					$orderid = mysqli_insert_id($connection);
					foreach ($cart as $key => $value) {

						$ordsql = "SELECT * FROM products WHERE id=$key";
						$ordres = mysqli_query($connection, $ordsql);
						$ordr = mysqli_fetch_assoc($ordres);

						$pid = $ordr['id'];
						$productprice = $ordr['price'];
						$quantity = $value['quantity'];


						$orditmsql = "INSERT INTO orderitems (pid, orderid, productprice, pquantity) VALUES ('$pid', '$orderid', '$productprice', '$quantity')";
						$orditmres = mysqli_query($connection, $orditmsql) or die(mysqli_error($connection));



					}
				}
				unset($_SESSION['cart']);
				header("location: my-account.php");
			}

		}
	}

}

$sql = "SELECT * FROM usersmeta WHERE uid=$uid";
$res = mysqli_query($connection, $sql);
$r = mysqli_fetch_assoc($res);

$x = 0;
	foreach ($cart as $key => $value) {

		$navcartsql = "SELECT * FROM products WHERE id=$key";
		$navcartres = mysqli_query($connection, $navcartsql);
		$navcartr = mysqli_fetch_assoc($navcartres);



								$x = $x + ($navcartr['price']*$value['quantity']);
								}

?>



		<section class="collierH">

	 	<div class="row">
	<div class="col-md-8">


	  <img class=" mb-3 d-block w-100 " src="images\checkout2.png" alt="second pic">
	  <span class="det-livraison"> Les details de livraisons</span>
	  <span class=" det-facturation">Les details de facturation</span>

	  <form method="post">
	    <div class="form-row">
	      <div class="form-group mt-3 col-md-6">
	        <label for="adresseP">Type d'adresse</label>
	        <select class="form-select form-control">
	          <option selected>
	            personnel
	          </option>
	          <option >
	            publique
	          </option>
	        </select>
	        <div class="form-group mt-3 col-md-6">

	</div>
	</div>
	</div>

	<div class="form-row">

	<div class="form-group mt-3 col-md-6">
	<label for="Nom">Prenom</label>
	<input required type="text" class="form-control mb-3" name="fname"placeholder="Veuillez entrer votre Prenom" value="<?php if(!empty($r['firstname'])){ echo $r['firstname']; } elseif(isset($fname)){ echo $fname; } ?>" aria-label="Rechercher" aria-describedby="basic-addon2">
	</div>

	<div class="form-group mt-3 col-md-6">
	<label for="Nom">Nom</label>
	<input required type="text" class="form-control mb-3" name="lname" placeholder="Veuillez entrer votre nom" value="<?php if(!empty($r['lastname'])){ echo $r['lastname']; }elseif(isset($lname)){ echo $lname; } ?>" aria-label="Rechercher" aria-describedby="basic-addon2">
	</div>

	<div class="form-group mt-3 col-md-6">
	<label for="Addresse1">Adresse</label>
	<input required name="address1" type="text" class="form-control mb-3" placeholder="Veuillez entrer votre Adresse"value="<?php if(!empty($r['address1'])){ echo $r['address1']; } elseif(isset($address1)){ echo $address1; } ?>" aria-label="Rechercher" aria-describedby="basic-addon2">
	</div>
	<div class="form-group mt-3 col-md-6">
		<label for="Zone">Zone</label>
		<input required name="state" type="text" class="form-control mb-3" placeholder="Ariana" value="<?php if(!empty($r['state'])){ echo $r['state']; }elseif(isset($state)){ echo $state; } ?>" aria-label="Rechercher" aria-describedby="basic-addon2">

	</div>
	<div class="form-group mt-3 col-md-6">
	<label for="Cité">Cité</label>
	<input required name="city" type="text" class="form-control mb-3" placeholder="Cité el ghazela" value="<?php if(!empty($r['city'])){ echo $r['city']; }elseif(isset($city)){ echo $city; } ?>" aria-label="Rechercher" aria-describedby="basic-addon2">
	</div>

	<div class="form-group mt-3 col-md-6">
	<label for="phone">Numéro de téléphone</label>
	<input required name="phone" id="billing_phone" type="text" class="form-control mb-3" placeholder="Numéro de téléphone" value="<?php if(!empty($r['mobile'])){ echo $r['mobile']; }elseif(isset($phone)){ echo $phone; } ?>"aria-label="Rechercher" aria-describedby="basic-addon2">
	</div>
	<div class="form-group mt-3 col-md-6">
	<label for="postale">code postale</label>
	<input required name="zipcode" type="text" class="form-control mb-3" placeholder="Entrer votre Code Postale" value="<?php if(!empty($r['zip'])){ echo $r['zip']; }elseif(isset($zip)){ echo $zip; } ?>" aria-label="Rechercher" aria-describedby="basic-addon2">
	</div>
	</div>




	<div>
		<div class="row mb-3">

				<div class="col-md-4 form-check">
					<input name="payment" id="radio1" class="form-check-input" type="radio" value="Espéce" checked><label class="form-check-label" for="flexRadioDefault1"  >paiement à la livraison</label>
				</div>
				<div class="col-md-4 form-check">
					<input name="payment" id="radio2" class="form-check-input" type="radio" value="Chéque"><label class="form-check-label" for="flexRadioDefault2">Paiement par chèque</label>
				</div>
				<div class="col-md-4 form-check">
					<input name="payment" id="radio3" class="form-check-input" type="radio" value="Paypal" ><label class="form-check-label" for="flexRadioDefault3">Paypal</label>

				</div>

		</div>
<div class="form-check mb-3">



			<input name="agree" id="checkboxG2" class="form-check-input" type="checkbox" value="true"> <label class="form-check-label" for="flexCheckDefault">J'ai lu et j'accepte <Strong><u>Les termes et les conditions</u></strong></label>
</div>

			<input type="submit" class="btn btn-dark mb-3" value="CONTINUE"></button>
	</div>



</form>


	</div>
	<div class="col-md-4 border mb-5  pb-4  h-25 position-sticky somme">


	<div class="pt-4">
	    <h6>Sommaire</h6>
	    <hr>
	    <div class="row price-details">
	        <div class="col-md-6">

	                  <h6>Prix (Articles)</h6>
	                    <hr />


	            <h6>Livraison</h6>
	            <hr>
	            <h6>Prix Total</h6>
	        </div>
	        <div class="col-md-6">
	            <h6> <?php echo $x ; ?> DT</h6>
	            <hr>
	            <h6 class="text-success">Gratuite</h6>
	            <hr>
	            <h6> <?php echo $x ; ?> DT</h6>
	        </div>
	    </div>

	</div>

	</div>

	</div>

	</section>

<?php include 'inc/footer.php' ?>
