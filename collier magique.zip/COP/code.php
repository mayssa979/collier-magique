<?php 
require "config/connect.php";
include "inc/header.php";
require "mdpoublie.php";
?>
<meta charset="utf-8">
<form method="POST" action="newpass.php" style ="margin-top:100px; margin-left:60px;height:300px;">
<h3>Nouveau Mot De Passe </h3>
<label for ="code" >Entrer votre Code</label><br>
<input type="text" name="code" style="width:250px;"><br>
<button type="submit" style="background-color:grey;color:white;margin-top:10px;width:250px;"
 <?php
 $code=$_POST['code'];
 if ($x==$code){
     echo "code vérifié";
 }
else{
    echo "error";
}

?>
>Envoyer</button>

</form>
<br><br>

<?php 


require "inc/footer.php"; ?>