<?php include 'inc/header.php'; ?>
<meta charset='UTF-8'>
<form method="post" action="mdpoublie.php" style ="margin-top:100px; margin-left:60px;height:300px;">
<h3 >Rénisialiser Votre mot de passe </h3>
<label for ="email" >Entrer votre Email</label><br>
<input type="email" name="email" style="width:250px;"><br>
<button type="submit" style="background-color:grey;color:white;margin-top:10px;width:250px;">Envoyer</button>
</form>
<br><br>

<?php include 'inc/footer.php'; ?>