<?php
session_start();
require_once 'config/connect.php';
include 'inc/header.php';
if (isset($_SESSION['cart'])){
$cart = $_SESSION['cart'];}
?>
<section>
    <div class="container ">
      <div class="row">
        <div class=" col-12 mt-5">
          <h2 class="mb-3">Panier</h2>
        </div>
        <div class="col-md-8">


      <?php
        //print_r($cart);
      
         $total = 0;
         if (isset($cart)){
        foreach ($cart as $key => $value) {
          //echo $key . " : " . $value['quantity'] ."<br>";
          $cartsql = "SELECT * FROM products WHERE id=$key";
          $cartres = mysqli_query($connection, $cartsql);
          $cartr = mysqli_fetch_assoc($cartres);
       ?>


       <div class="mb-5">
           <div class="row">
               <div class="col-md-3 px-0">
                   <a href="single.php?id=<?php echo $cartr['id']; ?>"><img src=<?php echo $cartr['thumb']; ?> alt="Image1" class="img-fluid"></a>
               </div>
               <div class="col-md-6">
                   <h4><?php echo substr($cartr['name'], 0 , 30); ?></h5>
                   <h5 class="pt-2"><?php echo $cartr['price']; ?> DT</h5>
                  
                     
                     <h6 class="pt-2">Quantité: <strong> 
                      <?php 
                      echo
                     $value['quantity']
                    
                     ?></strong> Articles </h5>
                     
                     
                    
                       <h6 class="pt-2">Total: <strong><?php echo ($cartr['price']*$value['quantity']); ?>.00 DT</strong> </h5>


               </div>
               <div class= "col-md-3 py-5 text-center">

                 <a href="delcart.php?id=<?php echo $key; ?>"><button  class="btn btn-dark mx-2" name="remove">RETIRER</button></a>

               </div>
           </div>
       </div>
       <hr />




      <?php
        $total = $total + ($cartr['price']*$value['quantity']);
      } }
      ?>

</div>








<div class="col-md-4 border mb-5  pb-4  h-25 position-sticky somme">

<div class="pt-4">
    <h6>Sommaire</h6>
    <hr>
    <div class="row price-details">
        <div class="col-md-6">
            <h6>Somme des articles</h6>
                  <hr>
            <h6>Livraison</h6>
            <hr>
            <h6>Prix Total</h6>
            <button class="btn btn-outline-dark btn-block lg-btn mt-3" onclick="goBack()">Revenir</button>
        </div>
        <div class="col-md-6">
            <h6><?php echo $total; ?>.00 DT</h6>
            <hr>
            <h6 class="text-success">Gratuite</h6>
            <hr>
            <h6>
              <strong><span><?php echo $total; ?>.00 DT</span></strong> </h6>
<a href="checkout.php" class="checkoutlink"><button class="btn btn-dark btn-block lg-btn mt-3">Commandez</button></a>
        </div>
    </div>

</div>

</div>
</div>




        </div>
      </div>
</section>

<?php include 'inc/footer.php' ?>
<script>
function goBack() {
  window.history.back();
}

</script>
