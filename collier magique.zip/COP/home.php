<?php session_start();
require_once 'config/connect.php';
 include 'inc/header.php'; ?>
<!-- first section -->
<section class="banner">
  <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active carousel-item-1">

<img class="d-block w-100 " src="images/section-1.jpg" alt="First slide">
<div class="carousel-caption d-none d-md-block">
    <h1>Découvrez la magie des colliers</h1>
    <p class="p-section1" >Achetez des cadeaux pour vous et vos proches</p>
    <button type="button" class="btn btn-outline-light btn-lg discover-btn">Découvrir</button>
  </div>
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/section-1.jpg" alt="Second slide">
    </div> 
    <div class="carousel-item">
      <img class="d-block w-100" src="images/section-1.jpg" alt="Third slide">
    </div>
  </div>  
    </div>

   
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
<div class="left-arrow">


    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
    </div>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
<div class="right-arrow">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
      </div>
  </a>

</div>
</section>

<section class="new-neck">
  <div class="titre-section">
    <h2>Nouveaux Colliers</h2>
<a href ="#"class="suite"  >VOIR PLUS</a>
  <a href ="#" > <i class="fas fa-plus"></i></a>
</div>
<div class="row row-space">
  <div class="col-md-6 overlay voir">
    <div class="shadow">
      <img class="d-block w-100 " src="images/1.png" alt="first pic">

  <div class="text-overlay">
<p>

Un design unique et attirant dans nos colliers</p>
<button type="button" class="btn btn-outline-light button-overlay">Voir plus</button>
</div>


</div>
  </div>
  <div class="col-lg-3">
    <div class="shadow">


    <div class="overlay">
      <img class="d-block w-100 " src="images/2.png" alt="second pic">
      <div class="new-overlay">
        Nouveau
      </div>
      
      </div>
    <div class="down-div py-3">
<p class="title-buy text-center">
  Nom du produit
</p>

<p class="price-buy text-center">
25.60 DT
</p>
    </div>
  </div>
</div>
  <div class="col-lg-3">
    <div class="shadow">

    <div class="overlay">

    <img class="d-block w-100 " src="images/3.png" alt="third pic">
    <div class="new-overlay">
      Nouveau
    </div>
    
    </div>
    <div class="down-div py-3">
<p class="title-buy text-center">
  Nom du produit
</p>
<p class="price-buy text-center">
25.60 DT
</p>
    </div>

  </div>
</div>
</div>
<div class="row row-space">

  <div class="col-lg-3">
    <div class="shadow">

    <div class="overlay">

    <img class="d-block w-100 " src="images/5.png" alt="second pic">
    <div class="new-overlay">
      Nouveau
    </div>
    
    </div>
    <div class="down-div py-3">
<p class="title-buy text-center">
  Nom du produit
</p>

<p class="price-buy text-center">
25.60 DT
</p>
    </div>
  </div>
  </div>
  <div class="col-lg-3">
    <div class="shadow">

    <div class="overlay">

    <img class="d-block w-100 " src="images/6.png" alt="third pic">
    <div class="new-overlay">
      Nouveau
    </div>
    
    </div>
    <div class="down-div py-3">
<p class="title-buy text-center">
  Nom du produit
</p>

<p class="price-buy text-center">
25.60 DT
</p>
    </div>
</div>
  </div>
  <div class="col-md-6 overlay voir">
    <div class="shadow">


<img class="d-block w-100 " src="images/4.png" alt="first pic">

  <div class="text-overlay">
<p>

Plusieurs marques n'attendent que vous pour les découvrir </p>
<button type="button" class="btn btn-outline-light button-overlay">Voir plus</button>
</div>



  </div>
</div>
</div>

</section>

<!-- section 3 bracelets -->

<section class="new-bracelets">
  <div class="titre-section titre-bracelets">
    <h2>Nouveaux Bracelets</h2>
<a href ="#"class="suite"  >VOIR PLUS</a>
  <a href ="#" > <i class="fas fa-plus"></i></a>
</div>

<div id="CarouselBracelets" class="carousel slide" data-ride="carousel" data-interval="0">

<div class="carousel-inner inner2">
  <div class="carousel-item active carousel-item-2">

    <div class="row row-space">

      <div class="col-lg-3 ">
        <div class="shadow">

        <div class="overlay">
          <img class="d-block w-100 " src="images/7.png" alt="second pic">
          <div class="new-overlay">
            Nouveau
          </div>
          
          </div>
        <div class="down-div py-3">
        <p class="title-buy text-center">
        Nom du produit
        </p>

        <p class="price-buy text-center">
        25.60 DT
        </p>

        </div>
      </div>
        </div>

        <div class="col-lg-3">
          <div class="shadow">

        <div class="overlay">

        <img class="d-block w-100 " src="images/8.png" alt="third pic">
        <div class="new-overlay">
          Nouveau
        </div>
        
        </div>
        <div class="down-div py-3">
        <p class="title-buy text-center">
        Nom du produit
        </p>

        <p class="price-buy text-center">
        25.60 DT
        </p>
        </div>
      </div>
        </div>

      <div class="col-lg-3">
        <div class="shadow">

        <div class="overlay">
          <img class="d-block w-100 " src="images/9.png" alt="second pic">
          <div class="new-overlay">
            Nouveau
          </div>
          
          </div>
        <div class="down-div py-3">
    <p class="title-buy text-center">
      Nom du produit
    </p>

    <p class="price-buy text-center">
    25.60 DT
    </p>
        </div>
      </div>
    </div>
      <div class="col-lg-3">
        <div class="shadow">

        <div class="overlay">

        <img class="d-block w-100 " src="images/10.png" alt="third pic">
        <div class="new-overlay">
          Nouveau
        </div>
       
        </div>
        <div class="down-div py-3">
    <p class="title-buy text-center">
      Nom du produit
    </p>

    <p class="price-buy text-center">
    25.60 DT
    </p>
        </div>

      </div>
    </div>
    </div>
  </div>

  <div class="carousel-item carousel-item-2">

        <div class="row row-space">

          <div class="col-lg-3">
            <div class="shadow">

            <div class="overlay">
              <img class="d-block w-100 " src="images/7.png" alt="second pic">
              <div class="new-overlay">
                Nouveau
              </div>
              
              </div>
            <div class="down-div py-3">
            <p class="title-buy text-center">
            Nom du produit
            </p>

            <p class="price-buy text-center">
            25.60 DT
            </p>
            </div>
            </div>
          </div>

            <div class="col-lg-3">
              <div class="shadow">

            <div class="overlay">

            <img class="d-block w-100 " src="images/8.png" alt="third pic">
            <div class="new-overlay">
              Nouveau
            </div>
            
            </div>
            <div class="down-div py-3">
            <p class="title-buy text-center">
            Nom du produit
            </p>

            <p class="price-buy text-center">
            25.60 DT
            </p>
            </div>
            </div>
          </div>

          <div class="col-lg-3">
            <div class="shadow">

            <div class="overlay">
              <img class="d-block w-100 " src="images/9.png" alt="second pic">
              <div class="new-overlay">
                Nouveau
              </div>
              
              </div>
            <div class="down-div py-3">
        <p class="title-buy text-center">
          Nom du produit
        </p>

        <p class="price-buy text-center">
        25.60 DT
        </p>
            </div>
          </div>
        </div>
          <div class="col-lg-3">
            <div class="shadow">

            <div class="overlay">

            <img class="d-block w-100 " src="images/10.png" alt="third pic">
            <div class="new-overlay">
              Nouveau
            </div>
            
            </div>
            <div class="down-div py-3">
        <p class="title-buy text-center">
          Nom du produit
        </p>

        <p class="price-buy text-center">
        25.60 DT
        </p>
            </div>

          </div>
        </div>
      </div>
  </div>
</div>
  <!-- <div class="carousel-item">
    <img class="d-block w-100" src="..." alt="Third slide">
  </div> -->


<a class="carousel-control-prev" href="#CarouselBracelets" role="button" data-slide="prev">
<div class="larrow2">


  <span class="carousel-control-prev-icon" aria-hidden="true"></span>
  <span class="sr-only">Previous</span>
  </div>
</a>
<a class="carousel-control-next" href="#CarouselBracelets" role="button" data-slide="next">
<div class="rarrow2">
  <span class="carousel-control-next-icon" aria-hidden="true"></span>
  <span class="sr-only">Next</span>
    </div>
</a>
</div>

</section>
<!-- section 4 banniere -->
<section class="banniere2">
  <div class="overlay">


<img src="images/11.png" class="d-block mw-100" />
<div class="banniere2-text" >
  <div style="display:inline-block;">
<h1 class="discount-title">50% OFF</h1>
<p class="discount2-title">On All Items</p>
  </div>
  <button type="button" class="btn btn-outline-light btn-lg shop-btn">SHOP NOW</button>
</div>
  </div>


</section>
<!-- section 5 produit réduit -->
<section class="discount">

  <div class="titre-section titre-bracelets">
    <h2>Nos produits à prix réduit</h2>
<a href ="promo.php"class="suite"  >VOIR PLUS</a>
  <a href ="#" > <i class="fas fa-plus"></i></a>
</div>

<div id="CarouselDiscount" class="carousel slide" data-ride="carousel" data-interval="0">

<div class="carousel-inner inner2">
  <div class="carousel-item active carousel-item-2">

    <div class="row row-space">

      <div class="col-lg-3">
        <div class="shadow">

        <div class="overlay">
          <img class="d-block w-100 " src="images/12.png" alt="second pic">

          
          </div>
        <div class="down-div py-3">
        <p class="title-buy text-center">
        Nom du produit
        </p>

        <p class="price-buy text-center">
        <span class="barré">25.60 DT</span> 21.50 DT
        </p>
        </div>
        </div>
      </div>

        <div class="col-lg-3">
          <div class="shadow">

        <div class="overlay">

        <img class="d-block w-100 " src="images/13.png" alt="third pic">

        
        </div>
        <div class="down-div py-3">
        <p class="title-buy text-center">
        Nom du produit
        </p>

        <p class="price-buy text-center">
        <span class="barré">25.60 DT</span> 21.50 DT
        </p>

        </div>
        </div>
      </div>

      <div class="col-lg-3">
        <div class="shadow">

        <div class="overlay">
          <img class="d-block w-100 " src="images/14.png" alt="second pic">

          
          </div>
        <div class="down-div py-3">
    <p class="title-buy text-center">
      Nom du produit
    </p>

    <p class="price-buy text-center">
    <span class="barré">25.60 DT</span> 21.50 DT
    </p>

        </div>
      </div>
      </div>
      <div class="col-lg-3">
        <div class="shadow">

        <div class="overlay">

        <img class="d-block w-100 " src="images/15.png" alt="third pic">

        
        </div>
        <div class="down-div py-3">
    <p class="title-buy text-center">
      Nom du produit
    </p>

    <p class="price-buy text-center">
    <span class="barré">25.60 DT</span> 21.50 DT
    </p>

        </div>
      </div>

      </div>
    </div>
  </div>

  <div class="carousel-item carousel-item-2">

        <div class="row row-space">

          <div class="col-lg-3">
            <div class="shadow">

            <div class="overlay">
              <img class="d-block w-100 " src="images/12.png" alt="second pic">

              
              </div>
            <div class="down-div py-3">
            <p class="title-buy text-center">
            Nom du produit
            </p>

            <p class="price-buy text-center">
            <span class="barré">25.60 DT</span> 21.50 DT
            </p>

            </div>
            </div>
          </div>

            <div class="col-lg-3">
              <div class="shadow">

            <div class="overlay">

            <img class="d-block w-100 " src="images/13.png" alt="third pic">

            
            </div>
            <div class="down-div py-3">
            <p class="title-buy text-center">
            Nom du produit
            </p>

            <p class="price-buy text-center">
            <span class="barré">25.60 DT</span> 21.50 DT
            </p>

          </div>
        </div>
            </div>

          <div class="col-lg-3">
            <div class="shadow">

            <div class="overlay">
              <img class="d-block w-100 " src="images/14.png" alt="second pic">

              
              </div>
            <div class="down-div py-3">
        <p class="title-buy text-center">
          Nom du produit
        </p>

        <p class="price-buy text-center">
        <span class="barré">25.60 DT</span> 21.50 DT
        </p>


      </div>
    </div>
          </div>
          <div class="col-lg-3">
            <div class="shadow">

            <div class="overlay">

            <img class="d-block w-100 " src="images/15.png" alt="third pic">

            
            </div>
            <div class="down-div py-3 ">
        <p class="title-buy text-center">
          Nom du produit
        </p>

        <p class="price-buy text-center">
        <span class="barré">25.60 DT</span> 21.50 DT
        </p>

            </div>

          </div>
        </div>
        </div>
  </div>
</div>
  <!-- <div class="carousel-item">
    <img class="d-block w-100" src="..." alt="Third slide">
  </div> -->


<a class="carousel-control-prev" href="#CarouselDiscount" role="button" data-slide="prev">
<div class="larrow2">


  <span class="carousel-control-prev-icon" aria-hidden="true"></span>
  <span class="sr-only">Previous</span>
  </div>
</a>
<a class="carousel-control-next" href="#CarouselDiscount" role="button" data-slide="next">
<div class="rarrow2">
  <span class="carousel-control-next-icon" aria-hidden="true"></span>
  <span class="sr-only">Next</span>
    </div>
</a>
</div>


</section>

<section class="contact">
  <div class="row">
<div class="col-lg-6 contact-face1">
  <h2 class="contact-header"> Prenez contact avec nous</h2>
  <p class="contact-msg"> nous serons à votre disposition à tout moment </p>
  <a href="contact.php" class="checkoutlink" ><button type="button" class="btn btn-outline-light btn-lg btn-contact">Contactez-nous</button></a>

</div>

<div class="col-lg-6 contact-face2">
  <img class="d-block w-100 " src="images/16.jpg" alt="second pic">
</div>
  </div>

</section>
<section class="gallery">
  <div class="row">


  <div class="col-lg-4 ">
<h2> Gallery </h2>
<p class=" text-gallery text-justify">
  Culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptartem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi ropeior architecto beatae vitae dicta sunt explicabo. Nemo eniem ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eosep quiklop ratione voluptatem sequi nesciunt. Neque porro quisquam est, quepi dolorem ipsum quia dolor srit amet, consectetur adipisci velit, seid quia non numquam eiuris modi tempora incidunt ut labore et dolore magnam aliquam quaerat iope voluptatem.
</p>

<p class=" text-gallery text-justify">
Lorem ipsum dolor sit amet, consectetur adipisifwcing elit, sed do eiusmod tempor incididunt ut labore et dolore roipi magna aliqua. Ut enim ad minim veeniam, quis nostruklad exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in tufpoy voluptate velit esse cillum dolore eu fugiat nulla parieratur. Excepteur sint occaecat cupidatat.
</p>
  </div>
<div class="col-lg-8">
  <img class="d-block w-100 " src="images/17.png" alt="second pic">

</div>
</div>
</section>
<?php include 'inc/footer.php' ?>
