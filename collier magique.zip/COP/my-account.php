<?php
	ob_start();
	session_start();
	require_once 'config/connect.php';
	if(!isset($_SESSION['customer']) & empty($_SESSION['customer'])){
		header('location: login.php');
	}

include 'inc/header.php';

$uid = $_SESSION['customerid'];
if (isset($_SESSION['cart'])){
$cart = $_SESSION['cart'];
} ?>

	<!-- SHOP CONTENT -->
	<section class="collierH" id="content">
		<div class="content-blog content-account">
				<div class="row">
					<!-- <div class="page_header text-center">
						<h2>My Account</h2>
					</div> -->
					<div class="col-md-8">

			<h3>Dernières commandes</h3>
			<br>
			<table class="table">
				<thead>
					<tr>
						<th>Commande</th>
						<th>Date</th>
						<th>Status</th>
						<th >Méthode de payement</th>
						<th>Total</th>
						<th></th>
					</tr>
				</thead>
				<tbody>

				<?php
				$styl='';
					$ordsql = "SELECT * FROM orders WHERE uid='$uid'";
					$ordres = mysqli_query($connection, $ordsql);
					while($ordr = mysqli_fetch_assoc($ordres)){
						if  ($ordr['orderstatus']=='Commande ajouté'){
							$styl='text-success';
						}
						else {
								$styl='text-danger';
						}

				?>
					<tr>
						<td>
		<?php echo $ordr['id']; ?>
						</td>


						<td>
							<?php echo $ordr['timestamp']; ?>
						</td>
						<td>
							<strong class="<?php echo $styl ?>">
							<?php echo $ordr['orderstatus']; ?>
</strong>
						</td>
						<td>
							<?php echo $ordr['paymentmode']; ?>
						</td>
						<td>
							 <?php echo $ordr['totalprice']; ?> DT
						</td>
						<td>
							<?php if($ordr['orderstatus'] != 'Annulé'){?>
						<a href="cancel-order.php?id=<?php echo $ordr['id']; ?>" class="checkoutlink "><button class="btn btn-dark">Annuler</button></a>
							<?php } ?>
						</td>
					</tr>
				<?php } ?>
				</tbody>
			</table>
		</div>

			<br>
			<br>
			<br>


			<div class="col-md-4 border mb-5  pb-4  h-25 position-sticky somme">


			<div class="pt-4">
			    <h6>Mes coordonnées</h6>
					<?php
						$csql = "SELECT u1.firstname, u1.lastname, u1.address1, u1.city, u1.state, u1.country, u1.company, u.email, u1.mobile, u1.zip FROM users u JOIN usersmeta u1 WHERE u.id=u1.uid AND u.id=$uid";
						$cres = mysqli_query($connection, $csql);
						if(mysqli_num_rows($cres) == 1){
							$cr = mysqli_fetch_assoc($cres);?>



			    <hr>
			    <div class="row price-details">
			        <div class="col-md-6">

			                  <h6>Nom Complet</h6>
			                    <hr />

													<h6>Téléphone</h6>
													<hr>
			            <h6>Adresse</h6>
			            <hr>
			            <h6>Cité</h6>
									<hr>
									<h6>Gouvernorat</h6>
									<hr>
									<h6>Code Postale</h6>
									<hr>

									<h6>E-mail</h6>
			        </div>
			        <div class="col-md-6">
			            <h6> <?php echo $cr['firstname'] ." ". $cr['lastname'] ; ?></h6>
			            <hr>
			            <h6><?php echo $cr['mobile'] ; ?></h6>
			            <hr>
			            <h6> <?php echo $cr['address1'] ; ?> </h6>
									<hr />
									<h6> <?php echo $cr['city'] ; ?> </h6>
									<hr />
									<h6> <?php echo $cr['state'] ; ?> </h6>
									<hr />
									<h6> <?php echo $cr['zip'] ; ?> </h6>
									<hr />
									<h6> <?php echo $cr['email'] ; ?> </h6>

			        </div>
			    </div>

			</div>
			<?php
									}
								?>
			</div>
				</div>
		</div>
	</section>

<?php include 'inc/footer.php' ?>
