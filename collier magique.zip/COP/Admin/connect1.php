<?php
session_start();

$mysqli = new mysqli('localhost', 'root', '', 'ecomphp') or die(mysqli_error($mysqli)) ;
$update=false;
$user='';
$mdp='';
$nom='';
$prenom='';
$email='';
if (isset($_POST['Ajouter'])){
    $user= $_POST['id'] ;
    $mdp= $_POST['password'] ;
    $nom= $_POST['firstname'] ;
    $prenom= $_POST['lastname'] ;
    $email= $_POST['email'] ;

    $mysqli->query("INSERT INTO admin (id, password, firstname , lastname, email) VALUES ('$user','$mdp','$nom','$prenom','$email')") or die($mysqli->error());
    $mysqli->query("CREATE USER '" . $user . "' IDENTIFIED BY '" . $mdp . "'");
    $_SESSION ['message'] ="L'ajout a été effectué avec succés!";
    $_SESSION ['msg_type']= "success";
    header("location: admins.php");
}

if (isset ($_GET['supprimer'])){
    $user= $_GET['supprimer'];
    $mysqli->query("DELETE FROM `admin` WHERE `admin`.`id` = '$user'") or die($mysqli->error());

    $_SESSION ['message'] ="La supression a été effectué avec succés!";
    $_SESSION ['msg_type']= "danger";
}


if (isset($_GET['modifier'])){
    $user= $_GET['modifier'];
    $update=true;
    $resultat= $mysqli->query("SELECT * FROM `admin` WHERE id = '$user'") or die($mysqli->error());
    if ($resultat->num_rows){
        $row = $resultat->fetch_array();
        $user= $row['id'] ;
        $mdp= $row['password'] ;
        $nom= $row['firstname'] ;
        $prenom= $row['lastname'] ;
        $email= $row['email'] ;
    }
}

if (isset($_POST['maj'])){
  $user= $_POST['id'] ;
  $mdp= $_POST['password'] ;
  $nom= $_POST['firstname'] ;
  $prenom= $_POST['lastname'] ;
  $email= $_POST['email'] ;
    $mysqli->query("UPDATE admin SET  id='$user' ,password = '$mdp', firstname= '$nom', lastname = '$prenom', email = '$email' WHERE id = '$user'") or die($mysqli->error());
    $_SESSION ['message'] ="La mise à jour a été effectué avec succés!";
    $_SESSION ['msg_type']= "warning";
    header("location: admins.php");


}
?>
