<html>
<head>
    <title> CRUD </title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/jquery.min"></script>
    <script src="js/bootstrap.min.js"></script>

</head>
<body>
<?php
session_start();


$mysqli = new mysqli('localhost', 'root', '', 'ecomphp') or die(mysqli_error($mysqli)) ;
if (isset($_POST['user'])){
    $uname=$_POST['user'];
    $password=$_POST['pass'];
    $result= $mysqli->query ("select * from admin where firstname='".$uname."'AND password='".$password."' limit 1 ;");
    if($result->num_rows){
        header("location:  admins.php");
    }
    else{
        $_SESSION ['message'] ="Vos coordonnées sont incorrectes";
        $_SESSION ['msg_type']= "danger";
    }
}

?>
<?php
if (isset($_SESSION['message'])):
?>
<div class="alert alert-<?=$_SESSION['msg_type'] ?> mb-0">
    <?php
        echo $_SESSION['message'];
        unset ($_SESSION['message']);
           ?>
           </div>
           <?php endif ?>


<div class="container">


<div class="row justify-content-center">
    <form action="#" method="POST">
    <img src="logo.png"  alt ="logo"class="img-fluid my-5">
        <div class="form-group">
            <label>Entrer votre nom d'utilisateur</label>
            <input type="text" name="user" class="form-control" placeholder="Utilisateur">
        </div>
        <div class="form-group">
            <label>Entrer votre mot de passe </label>
            <input type="password" name="pass" class="form-control" placeholder="Mot de passe">
        </div>
        <div class="form-group justify-content-center">
            <button type="submit" class="btn btn-primary" name="connect">Se connecter</button>

        </div>

    </form>
</div>
</div>


</body>

</html>
