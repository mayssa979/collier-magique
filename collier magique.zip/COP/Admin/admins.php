<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="style.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/all.css" integrity="sha384-vp86vTRFVJgpjF9jiIGPEEqYqlDwgyBgEF109VFjmqGmIY/Y4HV4d3Gp2irVfcrp" crossorigin="anonymous">
  <script src="https://kit.fontawesome.com/2a853d84af.js" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <title>administrateur log</title>
</head>

<body>
  <?php require_once 'connect1.php';?>
  <div class="wrapper">

    <!-- Sidebar -->
    <nav id="sidebar">
      <div class="sidebar-header">
        <a class="navbar-brand" href=""><img class="img-fluid d-block mx-auto" src="logo.png"></a>
      </div>
      <ul class="list-unstyled components">
        <li>
          <a href="index.php"><i class="fas fa-chart-bar"></i>statistique</a>
        </li>
        <li>
          <a href="admins.php"><i class="fas fa-user-cog"></i>admins</a>
        </li>
        <li>
          <a href="client.php"><i class="fas fa-users"></i>client</a>
        </li>
        <li>
          <a href="gest.php"><i class="fas fa-box-open"></i>gestion de stock</a>
        </li>
        <li>
          <a href="comd.php"><i class="fas fa-archive"></i>commande</a>
        </li>
        <li>
          <a href="msg.php"><i class="fas fa-envelope-open-text"></i>messages</a>
        </li>
      </ul>


    </nav>


    <!-- Page Content -->
    <div id="content">
    
      <div class="container-fluid">
        <?php
                $mysqli = new mysqli('localhost', 'root', '', 'ecomphp') or die(mysqli_error($mysqli)) ;
                $resultat =$mysqli->query ("SELECT * FROM admin") or die ($mysqli->error);
            ;
               ?>
        <div class="row justify-content-center table-responsive  ">
          <div class="text-center">

            <h1 class="font-weight-bold mb-5">Administrateur</h1>

          </div>
          <table class="table table-bordered table-hover table-success">

            <thead class="thead-dark">
              <tr>
                <th>Identifiant</th>
                <th>Nom d'administrateur</th>
                <th>Prénom d'administrateur</th>
                <th>Email</th>
                <th>Mot de passe</th>

                <th colspan="2">Action</th>
              </tr>
            </thead>
            <?php
                            while ($row=$resultat->fetch_array()):
                        ?>
            <tbody class="table-hover">


              <tr>
                <th scope="row"><?php echo $row['id']; ?></td>
                <td><?php echo $row['firstname']; ?></td>
                <td><?php echo $row['lastname']; ?></td>
                <td><?php echo $row['email']; ?></td>
                <td><?php echo $row['password']; ?></td>

                <td>
                  <a href="admins.php?modifier=<?php echo $row['id'] ?>" class="btn btn-info"><i class="far fa-edit"></i></a>
                  <a href="admins.php?supprimer=<?php echo $row['id'] ?>" class="btn btn-danger"><i class="far fa-trash-alt"></i></a>
                </td>
              </tr>
            </tbody>
            <?php endwhile; ?>
          </table>
        </div>

        <div class="row justify-content-center">
          <form action="connect1.php" method="POST">
            <input type="hidden" name="user" value="<?php echo $user;?> ">
            <div class="form-group">


              <div class="row">
                <div class="col-md">
                  <label class="font-weight-bold">Administrateur</label>
                  <input type="text" name="id" class="form-control" value="<?php echo $user ;?>" placeholder="Entrer nom d utilisateur">
                </div>
                <div class="col-md">
                  <label class="font-weight-bold">Mot de passe</label>
                  <input type="text" name="password" class="form-control" value="<?php echo $mdp; ?>" placeholder="Entrer le mot de pass">
                </div>
              </div>
              <div class="form-group">
                <div class="row">
                  <div class="col-md">
                    <label class="font-weight-bold">Nom</label>
                    <input type="text" name="firstname" class="form-control" value="<?php echo $nom; ?>" placeholder="Entrer le nom de l admin">
                  </div>
                  <div class="col-md">
                    <label class="font-weight-bold">Prénom</label>
                    <input type="text" name="lastname" class="form-control" value="<?php echo $prenom; ?>" placeholder="Entrer le prenom de l admin">
                  </div>
                </div>
              </div>
              <div class="form-group">
                <div class="row">
                  <div class="col-md">

                    <label class="font-weight-bold">Email</label>
                    <input type="text" name="email" class="form-control" value="<?php echo $email; ?>" placeholder="Entrer l'email'">
                  </div>

                </div>
              </div>
            </div>


            <div class="form-group">
              <?php
                    if ($update == true):
                    ?>
              <button type="submit" class="btn btn-info" name="maj">Mettre à jour</button>
              <?php else: ?>
              <div class="form-group">
                <button type="submit" class="btn btn-primary font-weight-bold" name="Ajouter">Ajouter</button>
                <?php endif; ?>
              </div>
            </div>
          </form>
        </div>

      </div>
    </div>
  </div>

  </div>
  </div>
  <script type="text/javascript">
    $(document).ready(function() {
      $('#sidebarCollapse').on('click', function() {
        $('#sidebar').toggleClass('active');
      });
    });
  </script>




</body>

</html>
