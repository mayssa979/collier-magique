<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="style.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/all.css" integrity="sha384-vp86vTRFVJgpjF9jiIGPEEqYqlDwgyBgEF109VFjmqGmIY/Y4HV4d3Gp2irVfcrp" crossorigin="anonymous">
  <script src="https://kit.fontawesome.com/2a853d84af.js" crossorigin="anonymous"></script>
  <title>administrateur log</title>
</head>

<body>
  <div class="wrapper">

    <!-- Sidebar -->
    <nav id="sidebar">
      <div class="sidebar-header">
        <a class="navbar-brand" href=""><img class="img-fluid d-block mx-auto" src="logo.png"></a>
      </div>
      <ul class="list-unstyled components">
        <li>
        <a  href="index.php"><i class="fas fa-chart-bar"></i>statistique</a>
        </li>
        <li>
          <a  href="admins.php"><i class="fas fa-user-cog"></i>admins</a>
        </li>
        <li>
          <a href="client.php"><i class="fas fa-users"></i>client</a>
        </li>
        <li>
          <a href="gest.php"><i class="fas fa-box-open"></i>gestion de stock</a>
        </li>
        <li>
          <a href="comd.php"><i class="fas fa-archive"></i>commande</a>
        </li>
        <li>
          <a href="msg.php"><i class="fas fa-envelope-open-text"></i>messages</a>
        </li>
      </ul>


    </nav>

    <!-- Page Content -->
    <div id="content">
      <nav class="navbar navbar-expand-lg navbar-light bg-light">
          <div class="container-fluid">

              <button type="button" id="sidebarCollapse" class="btn btn-info">
                  <i class="fas fa-align-left"></i>
                  <span>Toggle Sidebar</span>
              </button>
              <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                  <i class="fas fa-align-justify"></i>
              </button>
              </div>
            </nav>


            <div class="line"></div>


            <div class="line"></div>


            <div class="line"></div>

    </div>
  </div>
<script type="text/javascript">
    $(document).ready(function () {
        $('#sidebarCollapse').on('click', function () {
            $('#sidebar').toggleClass('active');
        });
    });
</script>




</body>

</html>
