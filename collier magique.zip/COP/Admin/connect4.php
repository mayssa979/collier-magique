<?php
session_start();

$mysqli = new mysqli('localhost', 'root', '', 'ecomphp') or die(mysqli_error($mysqli)) ;

if (isset ($_GET['supprimer'])){
    $id= $_GET['supprimer'];
    $mysqli->query("DELETE FROM `orders` WHERE `orders`.`id` = '$id'") or die($mysqli->error());

    $_SESSION ['message'] ="La supression a été effectué avec succés!";
    $_SESSION ['msg_type']= "danger";
}

?>
