<?php
session_start();

$mysqli = new mysqli('localhost', 'root', '', 'ecomphp') or die(mysqli_error($mysqli)) ;

if (isset ($_GET['supprimer'])){
    $msg= $_GET['supprimer'];
    $mysqli->query("DELETE FROM `reviews` WHERE `reviews`.`msg` = '$msg'") or die($mysqli->error());

    $_SESSION ['message'] ="La supression a été effectué avec succés!";
    $_SESSION ['msg_type']= "danger";
}

?>
