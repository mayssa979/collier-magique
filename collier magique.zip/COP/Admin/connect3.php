<?php
//session_start();

$mysqli = new mysqli('localhost', 'root', '', 'ecomphp') or die(mysqli_error($mysqli)) ;
$update=false;
$id='';
$name='';
$catid='';
$price='';
$thumb='';
$description='';
if (isset($_POST['Ajouter'])){
  $id= $_POST['id'] ;
  $name= $_POST['name'] ;
  $catid= $_POST['catid'] ;
    $price= $_POST['price'] ;
    $thumb= $_POST['thumb'] ;
    $description= $_POST['description'] ;

    $mysqli->query("INSERT INTO products (id, name, catid , price, thumb,description) VALUES ('$id','$name','$catid','$price','$thumb','$description')") or die($mysqli->error());
    $_SESSION ['message'] ="L'ajout a été effectué avec succés!";
    $_SESSION ['msg_type']= "success";
    header("location: gest.php");
}

if (isset ($_GET['supprimer'])){
    $id= $_GET['supprimer'];
    $mysqli->query("DELETE FROM `products` WHERE `products`.`id` = '$id'") or die($mysqli->error());

    $_SESSION ['message'] ="La supression a été effectué avec succés!";
    $_SESSION ['msg_type']= "danger";
}


if (isset($_GET['modifier'])){
    $id= $_GET['modifier'];
    $update=true;
    $resultat= $mysqli->query("SELECT * FROM `products` WHERE id = '$id'") or die($mysqli->error());
    if ($resultat->num_rows){
        $row = $resultat->fetch_array();
        $id= $row['id'] ;
        $name= $row['name'] ;
        $catid= $row['catid'] ;
        $price= $row['price'] ;
        $thumb= $row['thumb'] ;
        $description= $row['description'] ;
    }
}

if (isset($_POST['maj'])){
  $id= $_POST['id'] ;
  $name= $_POST['name'] ;
  $catid= $_POST['catid'] ;
    $price= $_POST['price'] ;
    $thumb= $_POST['thumb'] ;
    $description= $_POST['description'] ;
    $mysqli->query("UPDATE products SET  id='$id' ,name = '$name', catid= '$catid', price= '$price', thumb = '$thumb' , description ='$description' WHERE id = '$id'") or die($mysqli->error());
    $_SESSION ['message'] ="La mise à jour a été effectué avec succés!";
    $_SESSION ['msg_type']= "warning";
    header("location: gest.php");


}
?>
