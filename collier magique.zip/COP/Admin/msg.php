<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="style.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/all.css" integrity="sha384-vp86vTRFVJgpjF9jiIGPEEqYqlDwgyBgEF109VFjmqGmIY/Y4HV4d3Gp2irVfcrp" crossorigin="anonymous">
  <script src="https://kit.fontawesome.com/2a853d84af.js" crossorigin="anonymous"></script>
  <title>administrateur log</title>
</head>

<<body>
    <?php require_once 'connect5.php';?>
  <div class="wrapper">

    <!-- Sidebar -->
    <nav id="sidebar">
      <div class="sidebar-header">
        <a class="navbar-brand" href=""><img class="img-fluid d-block mx-auto" src="logo.png"></a>
      </div>
      <ul class="list-unstyled components">
        <li>
        <a  href="index.php"><i class="fas fa-chart-bar"></i>statistique</a>
        </li>
        <li>
          <a  href="admins.php"><i class="fas fa-user-cog"></i>admins</a>
        </li>
        <li>
          <a href="client.php"><i class="fas fa-users"></i>client</a>
        </li>
        <li>
          <a href="gest.php"><i class="fas fa-box-open"></i>gestion de stock</a>
        </li>
        <li>
          <a href="comd.php"><i class="fas fa-archive"></i>commande</a>
        </li>
        <li>
          <a href="msg.php"><i class="fas fa-envelope-open-text"></i>messages</a>
        </li>
      </ul>


    </nav>

    <!-- Page Content -->
    <div id="content">
      
      <div class="container-fluid">
        <?php
                $mysqli = new mysqli('localhost', 'root', '', 'ecomphp') or die(mysqli_error($mysqli)) ;
                $resultat =$mysqli->query ("SELECT * FROM reviews") or die ($mysqli->error);
            ;
               ?>
        <div class="row justify-content-center table-responsive">
          <div class="text-center">


          <h1 class="font-weight-bold mb-5">Message des clients</h1>
            </div>
          <table class="table table-bordered table-hover table-success ">

            <thead class="thead-dark">
              <tr>
                <th>Nom complet</th>
                <th>Email</th>
                <th>Sujet</th>
                  <th>Message</th>
                <th>Action</th>
              </tr>
            </thead>
            <?php
                            while ($row=$resultat->fetch_array()):
                        ?>
            <tr>

              <td><?php echo $row['nomc']; ?></td>
              <td><?php echo $row['email']; ?></td>
                <td><?php echo $row['sujet']; ?></td>
                <td><?php echo $row['msg']; ?></td>
              <td>
                <a href="msg.php?supprimer=<?php echo $row['msg'] ?>" class="btn btn-danger"><i class="far fa-trash-alt"></i></a>
              </td>
            </tr>
            <?php endwhile; ?>
          </table>
        </div>


      </div>
    </div>
  </div>

  </div>
  </div>
  <script type="text/javascript">
    $(document).ready(function() {
      $('#sidebarCollapse').on('click', function() {
        $('#sidebar').toggleClass('active');
      });
    });
  </script>


</body>

</html>
