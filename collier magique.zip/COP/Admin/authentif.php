<?php
session_start();

$mysqli = new mysqli('localhost', 'root', '', 'ecomphp') or die(mysqli_error($mysqli)) ;

$user=$_POST['user'];
$pass=$_POST['pass'];

if (isset($_POST['connect'])){
    $resultat= $mysqli->query("SELECT * FROM admin WHERE id='".$user."' AND password='".$pass."';");
}
    if ($resultat->num_rows){
        header("location: auth.php");
    }
    else
     {
        header("location: index.php");


    }






?>
