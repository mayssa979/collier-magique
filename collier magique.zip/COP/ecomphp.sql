-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 02, 2021 at 08:42 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecomphp`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `firstname`, `lastname`, `email`, `password`) VALUES
(2, 'yassin', 'khabthani', 'yassinokhb@hotmail.fr', '123456'),
(3, 'ahmed', 'achour', 'abdelaziz.khabthani@gmail.com', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`) VALUES
(1, 'HOMME'),
(2, 'FEMME'),
(3, 'HOMME'),
(4, 'FEMME');

-- --------------------------------------------------------

--
-- Table structure for table `orderitems`
--

CREATE TABLE `orderitems` (
  `id` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `pquantity` varchar(255) NOT NULL,
  `orderid` int(11) NOT NULL,
  `productprice` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orderitems`
--

INSERT INTO `orderitems` (`id`, `pid`, `pquantity`, `orderid`, `productprice`) VALUES
(36, 654, '1', 36, '30.000'),
(37, 612, '1', 36, '30.000'),
(38, 610, '1', 37, '45.000'),
(39, 654, '1', 38, '30.000'),
(40, 610, '1', 39, '45.000'),
(41, 654, '1', 40, '30.000'),
(42, 653, '1', 41, '45.000'),
(43, 654, '1', 42, '30.000'),
(44, 654, '1', 43, '30.000'),
(45, 654, '1', 44, '30.000'),
(46, 653, '1', 45, '45.000'),
(47, 643, '1', 46, '30.000'),
(48, 644, '1', 46, '30.000'),
(49, 673, '1', 47, '35.000'),
(50, 654, '1', 48, '30.000'),
(51, 668, '1', 48, '30.000');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `totalprice` varchar(255) NOT NULL,
  `orderstatus` varchar(255) NOT NULL,
  `paymentmode` varchar(255) NOT NULL,
  `timestamp` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `uid`, `totalprice`, `orderstatus`, `paymentmode`, `timestamp`) VALUES
(39, 22, '45', 'Commande ajouté', 'Espéce', '2021-02-08 03:17:12'),
(40, 22, '30', 'Annulé', 'Espéce', '2021-02-08 03:28:42'),
(41, 22, '45', 'Commande ajouté', 'Espéce', '2021-02-08 03:30:57'),
(42, 22, '30', 'Annulé', 'Espéce', '2021-02-08 03:35:41'),
(44, 22, '30', 'Annulé', 'Espéce', '2021-02-08 08:53:39'),
(45, 24, '45', 'Annulé', 'Espéce', '2021-02-08 11:45:41'),
(46, 24, '60', 'Commande ajouté', 'Espéce', '2021-02-08 11:56:53'),
(47, 24, '35', 'Commande ajouté', 'Paypal', '2021-02-08 14:16:28'),
(48, 25, '60', 'Annulé', 'Espéce', '2021-02-09 20:09:22');

-- --------------------------------------------------------

--
-- Table structure for table `ordertracking`
--

CREATE TABLE `ordertracking` (
  `id` int(11) NOT NULL,
  `orderid` int(11) NOT NULL,
  `status` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `timestamp` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ordertracking`
--

INSERT INTO `ordertracking` (`id`, `orderid`, `status`, `message`, `timestamp`) VALUES
(11, 36, 'Cancelled', ' ', '2021-02-07 18:20:02'),
(12, 38, 'Cancelled', ' ', '2021-02-08 03:17:22'),
(13, 40, 'Cancelled', ' ', '2021-02-08 03:28:49'),
(14, 42, 'Cancelled', ' ', '2021-02-08 03:36:44'),
(15, 44, 'Cancelled', ' aaaaaaa', '2021-02-08 08:54:01'),
(16, 45, 'Cancelled', ' yeye', '2021-02-08 11:45:50'),
(17, 48, 'Cancelled', ' ', '2021-02-09 20:09:38');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `catid` int(11) NOT NULL,
  `price` varchar(255) NOT NULL,
  `thumb` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `catid`, `price`, `thumb`, `description`) VALUES
(610, 'Bracelet tourmanile\r\n', 3, '45.000', 'produits/brhomme/2.jpg', 'Marque : France Minéraux\r\nType de bijoux : Bracelet\r\nType de pierre : Tourmaline noire\r\nType de perle : Boules\r\nTaille de perle : 8mm\r\nType de fermeture et de fil :\r\n\r\nSans fermoir – Fil Élastique\r\nFermoir Argent 925 – Fil Acier\r\nFermoir Or 14 Carats – Fi'),
(611, 'Bracelet Troumanile Noire\r\n', 3, '30.000', 'produits/brhomme/3.jpg', 'Marque : France Minéraux\r\nType de bijoux : Bracelet\r\nType de pierre : Agate noire\r\nType de perle : Boules\r\nTaille de perle : 8mm\r\nType de fermeture et de fil :\r\n\r\nSans fermoir – Fil Élastique\r\nFermoir Argent 925 – Fil Acier\r\nFermoir Or 14 Carats – Fil Cui'),
(612, 'Bracelet lapis lazuli', 3, '30.000', 'produits/brhomme/4.jpg', 'Marque : France Minéraux\r\nType de bijoux : Bracelet\r\nType de pierre : Shungite\r\nType de perle : Boules\r\nTaille de perle : 8mm\r\nType de fermeture et de fil :\r\n\r\nSans fermoir – Fil Élastique\r\nFermoir Argent 925 – Fil Acier\r\nFermoir Or 14 Carats – Fil Cuivre'),
(613, 'Bracelet obsidienne\r\n', 3, '42.000', 'produits/brhomme/5.jpg', 'Marque : France Minéraux\r\nType de bijoux : Bracelet\r\nType de pierre : Agate noire\r\nType de perle : Boules\r\nTaille de perle : 6mm\r\nType de fermeture et de fil :\r\n\r\nSans fermoir – Fil Élastique\r\nFermoir Argent 925 – Fil Acier\r\nFermoir Or 14 Carats – Fil Cui'),
(614, 'Bracelet Howlite\r\n', 3, '30.000', 'produits/brhomme/6.jpg', 'Marque : France Minéraux\r\nType de bijoux : Bracelet\r\nType de pierre : Howlite\r\nType de perle : Boules\r\nTaille de perle : 8mm\r\nType de fermeture et de fil :\r\n\r\nSans fermoir – Fil Élastique\r\nFermoir Argent 925 – Fil Acier\r\nFermoir Or 14 Carats – Fil Cuivre\r'),
(615, 'Bracelet Turquoise\r\n', 3, '28.000', 'produits/brhomme/7.jpg', 'Marque : France Minéraux\r\nType de bijoux : Bracelet\r\nType de pierre : Turquoise\r\nType de perle : Boules\r\nTaille de perle : 6mm\r\nType de fermeture et de fil :\r\n\r\nSans fermoir – Fil Élastique\r\nFermoir Argent 925 – Fil Acier\r\nFermoir Or 14 Carats – Fil Cuivr'),
(616, 'Bracelet obsidienne neige\r\n\r\n\r\n', 3, '17.000', 'produits/brhomme/8.jpg', 'Marque : France Minéraux\r\nType de bijoux : Bracelet\r\nType de pierre : Obsidienne noire\r\nType de perle : Boules\r\nTaille de perle : 8mm\r\nType de fermeture et de fil :\r\n\r\nSans fermoir – Fil Élastique\r\nFermoir Argent 925 – Fil Acier\r\nFermoir Or 14 Carats – Fi'),
(617, 'Bracelet Howlite', 3, '35.000', 'produits/brhomme/9.jpg', 'Marque : France Minéraux\r\nType de bijoux : Bracelet\r\nType de pierre : Howlite\r\nType de perle : Boules\r\nTaille de perle : 8mm\r\nType de fermeture et de fil :\r\n\r\nSans fermoir – Fil Élastique\r\nFermoir Argent 925 – Fil Acier\r\nFermoir Or 14 Carats – Fil Cuivre\r'),
(618, 'Bracelet Obsidienne noire', 3, '35.000', 'produits/brhomme/10.jpg', 'Marque : France Minéraux\r\nType de bijoux : Bracelet\r\nType de pierre : Obsidienne flocon de neige\r\nType de perle : Boules\r\nTaille de perle : 8mm\r\nType de fermeture et de fil :\r\n\r\nSans fermoir – Fil Élastique\r\nFermoir Argent 925 – Fil Acier\r\nFermoir Or 14 C'),
(619, 'Bracelet taureau\r\n\r\n', 3, '55.000', 'produits/brhomme/11.jpg', 'Marque : France Minéraux\r\nType de bijoux : Bracelet\r\nType de pierre : Oeil de taureau\r\nType de perle : Boules\r\nTaille de perle : 8mm\r\nType de fermeture et de fil :\r\n\r\nSans fermoir – Fil Élastique\r\nFermoir Argent 925 – Fil Acier\r\nFermoir Or 14 Carats – Fil'),
(620, 'Bracelet tourmaline noire', 3, '25.000', 'produits/brhomme/1.jpg', 'Marque : France Minéraux\r\nType de bijoux : Bracelet\r\nType de pierre : Tourmaline noire\r\nType de perle : Boules\r\nTaille de perle : 8mm\r\nType de fermeture et de fil :\r\n\r\nSans fermoir – Fil Élastique\r\nFermoir Argent 925 – Fil Acier\r\nFermoir Or 14 Carats – Fi'),
(642, 'Bracelet chaine porte\r\n', 4, '45.000', 'produits/brfemme/2.jpeg', '\r\n  Marque: SC CRYSTAL\r\n  Genre: Femme\r\n  Référence: M093381\r\n  Code: EAN3700600725057\r\n  Garantie12: mois\r\n  Type de bracelet: Bracelet rigide\r\n\r\n'),
(643, 'Bracelet blanc \r\n', 4, '30.000', 'produits/brfemme/3.jpeg', '\r\n   Marque: SC CRYSTAL\r\n   Genre: Femme\r\n   Référence: M093381\r\n   Code: EAN3700600725057\r\n   Garantie12: mois\r\n   Type de bracelet: Bracelet rigide\r\n\r\n'),
(644, 'Bracelet plaqué or zirconia\r\n', 4, '30.000', 'produits/brfemme/4.jpeg', 'MarqueMATY\r\nGenreFemme\r\nRéférence: 0681598\r\nPoids du produit: 1.02 g\r\nCouleur(s): Jaune\r\nMatière: Plaqué or jaune\r\nType de bracelet: Bracelet souple\r\nType de fermoir: Mousqueton\r\nLongueur: 18 cm\r\nDIMENSIONS\r\nLargeur maxi de(s) motif(s) :18 cm\r\nHauteur max'),
(645, 'Bracelet fantaisie cristal\r\n\r\n', 4, '42.000', 'produits/brfemme/5.jpeg', 'MarqueMATY\r\nGenre: Femme\r\nRéférence: 0273406\r\nCouleur(s): Gris\r\nType de pierre: de synthèseCristal de swarovski\r\nMatière: Métal argenté\r\nType de braceletBracelet rigide\r\nDiamètre64 mm\r\n\r\n'),
(646, 'Bracelet argent\r\n', 4, '30.000', 'produits/brfemme/6.jpeg', 'MarqueMATY\r\nGenre: Enfant / Femme\r\nRéférence: 0666050\r\nPoids du produit: 4.00 g\r\nCouleur(s): Blanc\r\nMatière: Argent 925\r\nPoids moyen Argent4.00 grammes\r\nType de fermoirMousqueton\r\nType de mailleCheval et alternée\r\nType de braceletBracelet souple\r\nLongueur'),
(647, 'Bracelet argent 925 ', 4, '28.000', 'produits/brfemme/7.jpeg', 'CARACTÉRISTIQUES BRACELET SOUPLE\r\nBRACELET en argent 925, motif oiseau orné de zirconias blancs et zirconia rouge dans loeil. Fermoir mousqueton. Longueur 21 cm avec deux anneaux de raccourcissement à 18 et 19.5 cm.\r\n\r\nMarqueMATY\r\nGenreFemme\r\nRéférence012'),
(648, 'Bracelet obsidienne', 4, '17.000', 'produits/brfemme/8.jpeg', 'CARACTÉRISTIQUES BRACELET SOUPLE\r\nBRACELET plaqué or maille fantaisie. Fermoir mousqueton. Longueur réglable de 16 à 17,5 cm.\r\n\r\nMarqueMATY\r\nGenreFemme\r\nRéférence0123901\r\nPoids du produit2.21 g\r\nCouleur(s)Jaune\r\nMatièrePlaqué or\r\nType de braceletBracelet '),
(649, 'Bracelet rigide argent 925\r\n', 4, '35.000', 'produits/brfemme/9.jpeg', 'CARACTÉRISTIQUES BRACELET RIGIDE\r\nBRACELET rigide argent 925. Tour de poignet réglable.\r\n\r\nMarqueMATY\r\nGenreFemme\r\nRéférence0668877\r\nPoids du produit3.63 g\r\nCouleur(s)Blanc\r\nMatièreArgent 925\r\nPoids moyen Argent3.63 grammes\r\nType de braceletBracelet rigid'),
(650, 'Bracelet argent 925', 4, '35.000', 'produits/brfemme/10.jpeg', 'CARACTÉRISTIQUES BRACELET SOUPLE\r\nBRACELET en argent 925, perles de culture de Chine. Longueur adaptable grâce à son fermoir coulissant.\r\n\r\nMarque: MATY\r\nGenre: Femme\r\nRéférence: 0126586\r\nPoids du produit: 11.00 g\r\nCouleur(s): Blanc\r\nMatière: Argent 925\r\n'),
(651, 'Bracelet  750\r\n\r\n', 4, '55.000', 'produits/brfemme/11.jpeg', 'CARACTÉRISTIQUES BRACELET SOUPLE\r\nBRACELET 2 750 (jaune, blanc). Fermoir bouée. Longueur 19 cm. 7,50 g.\r\n\r\nMarqueMATY\r\nGenreFemme\r\nRéférence0337242\r\nPoids du produit7.80 g\r\nCouleur(s)Blanc, Jaune\r\nMatièreOr 750 blanc, Or 750 jaune, 2 ors 750\r\nPoids moyen '),
(652, 'Bracelet plaqué\r\n', 4, '25.000', 'produits/brfemme/1.jpeg', 'CARACTÉRISTIQUES BRACELET SOUPLE\r\nBRACELET plaqué or, zirconias. Motif coeurs entrelacés. Fermoir mousqueton. Long. réglable de 17 à 18 cm.\r\n\r\nMarqueMATY\r\nGenreFemme\r\nRéférence0682047\r\nCouleur(s)Blanc, Jaune\r\nType de pierre de synthèseOxyde de zirconium d'),
(653, 'Collier acier 50 cm\r\n', 1, '45.000', 'produits/colhomme/2.png', '\r\n  CARACTÉRISTIQUES CHAÎNE\r\n  COLLIER acier. Fermoir mousqueton. Longueur 65 cm.\r\n\r\n  MarqueMATY\r\n  GenreHomme\r\n  Référence0440272\r\n  Poids du produit12.80 g\r\n  Couleur(s)Blanc\r\n  MatièreAcier\r\n  Type de collierChaîne\r\n  Type de fermoirMousqueton\r\n  Long'),
(654, 'Collier acier 65 cm\r\n\r\n', 1, '30.000', 'produits/colhomme/3.png', '\r\n   Marque: SC CRYSTAL\r\n   Genre: Femme\r\n   Référence: M093381\r\n   Code: EAN3700600725057\r\n   Garantie12: mois\r\n   Type de bracelet: Bracelet rigide\r\n\r\n'),
(655, 'Collier acier\r\n', 1, '30.000', 'produits/colhomme/4.png', 'CARACTÉRISTIQUES CHAÎNE\r\nCOLLIER en acier avec motif croix. Fermoir fantaisie. Longueur 60 cm.\r\n\r\nMarqueMATY\r\nGenreHomme\r\nRéférence0442658\r\nPoids du produit39.00 g\r\nCouleur(s)Gris\r\nMatièreAcier\r\nType de collierChaîne\r\nType de fermoirMousqueton\r\nLongueur d'),
(656, 'Collier acier\r\n\r\n', 1, '42.000', 'produits/colhomme/5.png', 'CARACTÉRISTIQUES COLLIER\r\nCOLLIER en acier avec motif fantaisie.\r\n\r\nMarqueMATY\r\nGenreHomme\r\nRéférence0442666\r\nPoids du produit50.00 g\r\nCouleur(s)Gris\r\nMatièreAcier\r\nType de collierCollier\r\nLongueur de la chaîneAutre\r\nType de mailleAutre\r\n\r\n'),
(657, 'Collier acier\r\n', 1, '30.000', 'produits/colhomme/6.png', 'CARACTÉRISTIQUES COLLIER\r\nCOLLIER en acier avec motif croix, dimensions 60 mm x 34 mm. Fermoir mousqueton. Longueur 60 cm.\r\n\r\nMarqueMATY\r\nGenreHomme\r\nRéférence0442623\r\nPoids du produit39.00 g\r\nCouleur(s)Gris\r\nMatièreAcier\r\nType de collierCollier\r\nType de '),
(658, 'Collier acier 62 cm\r\n', 1, '28.000', 'produits/colhomme/7.png', 'CARACTÉRISTIQUES COLLIER\r\nCOLLIER acier. Pampille noire et motif fantaisie. Longueur ajustable de 57 à 62 cm. Fermoir mousqueton.\r\n\r\nMarqueMATY\r\nGenreHomme\r\nRéférence0126845\r\nPoids du produit21.00 g\r\nCouleur(s)Gris, Noir\r\nMatièreAcier\r\nType de collierColl'),
(659, 'Collier acier 50 cm\r\n', 1, '17.000', 'produits/colhomme/8.png', 'CARACTÉRISTIQUES COLLIER\r\nCOLLIER acier, motif aile. Longueur ajustable de 45 à 50 cm. Fermoir mousqueton.\r\n\r\nMarqueMATY\r\nGenreHomme\r\nRéférence0124770\r\nPoids du produit4.00 g\r\nCouleur(s)Gris\r\nMatièreAcier\r\nType de collierCollier\r\nType de fermoirMousqueton'),
(660, 'Collier acier\r\n', 1, '35.000', 'produits/colhomme/9.jpg', 'CARACTÉRISTIQUES COLLIER\r\nCOLLIER en acier avec motif fantaisie. Longueur 65 cm.\r\n\r\nMarqueMATY\r\nGenreHomme\r\nRéférence0442640\r\nPoids du produit52.00 g\r\nCouleur(s)Gris\r\nMatièreAcier\r\nType de collierCollier\r\nLongueur de la chaîneAutre\r\n\r\n'),
(661, 'Collier argent 925', 1, '35.000', 'produits/colhomme/10.jpg', 'CARACTÉRISTIQUES COLLIER\r\nCOLLIER en argent 925, maille boule, pendentif tête de mort. Fermoir mousqueton. Longueur 50 cm.\r\n\r\nMarqueMATY\r\nGenreHomme\r\nRéférence0143987\r\nPoids du produit19.90 g\r\nCouleur(s)Blanc\r\nMatièreArgent 925\r\nPoids moyen Argent19.90 gr'),
(662, 'Collier acier onyx\r\n', 1, '55.000', 'produits/colhomme/11.jpg', 'CARACTÉRISTIQUES COLLIER\r\nCOLLIER acier, onyx. Longueur 69 cm. Fermoir mousqueton.\r\n\r\nMarqueMATY\r\nGenreHomme\r\nRéférence0127671\r\nPoids du produit75.00 g\r\nCouleur(s)Gris, Noir\r\nType de pierreOnyx\r\nMatièreAcier\r\nType de collierCollier\r\nType de fermoirMousque'),
(663, 'Collier acier\r\n', 1, '25.000', 'produits/colhomme/12.jpg', 'CARACTÉRISTIQUES COLLIER\r\nCOLLIER en acier avec motif panthère. Fermoir mousqueton. Longueur 65 cm.\r\n\r\nMarqueMATY\r\nGenreHomme\r\nRéférence0442631\r\nPoids du produit58.00 g\r\nCouleur(s)Gris\r\nMatièreAcier\r\nType de collierCollier\r\nType de fermoirMousqueton\r\nLong'),
(666, 'Collier acier 65 cm\r\n\r\n', 2, '45.000', 'produits/colfemme/2.png', '\r\n  CARACTÉRISTIQUES CHAÎNE\r\n  COLLIER acier. Fermoir mousqueton. Longueur 65 cm.\r\n\r\n  MarqueMATY\r\n  GenreHomme\r\n  Référence0440272\r\n  Poids du produit12.80 g\r\n  Couleur(s)Blanc\r\n  MatièreAcier\r\n  Type de collierChaîne\r\n  Type de fermoirMousqueton\r\n  Long'),
(667, 'Collier acier doré\r\n\r\n', 2, '30.000', 'produits/colfemme/3.png', '\r\nCARACTÉRISTIQUES COLLIER\r\nCOLLIER acier doré rose et nacre. Longueur réglable de 42 à 47 cm.\r\n\r\nMarqueMATY\r\nGenreFemme\r\nRéférence0443841\r\nPoids du produit12.00 g\r\nCouleur(s)Dore rose\r\nType de pierreNacre\r\nMatièreAcier\r\nType de collierCollier\r\nLongueur d'),
(668, 'Collier MATY Or\r\n', 2, '30.000', 'produits/colfemme/4.png', 'CARACTÉRISTIQUES COLLIER\r\nCOLLIER or jaune 375, 3 citrines total 74/100e de carat, 1 grenat 1,90 carat et 1 quartz fumé 1,10 carat. Longueur 45 cm avec un anneau de raccourcissement à 42 cm.\r\n\r\nMarqueMATY\r\nGenreFemme\r\nRéférence0114545\r\nPoids du produit2.7'),
(669, 'Collier plaqué\r\n\r\n', 2, '42.000', 'produits/colfemme/5.png', 'CARACTÉRISTIQUES COLLIER\r\nCOLLIER en plaqué or rose, perles de culture de Chine. Longueur réglable de 41.5 à 45 cm.\r\n\r\nMarqueMATY\r\nGenreFemme\r\nRéférence0119172\r\nPoids du produit4.85 g\r\nCouleur(s)Rose\r\nMatièrePlaqué or rose\r\nType de collierCollier\r\nType de'),
(670, 'Collier argent 925 topaze\r\n', 2, '30.000', 'produits/colfemme/6.png', 'CARACTÉRISTIQUES COLLIER\r\nCOLLIER argent 925, topazes bleues traitées et zirconias. Longueur 45 cm.\r\n\r\nMarqueMATY\r\nGenreFemme\r\nRéférence0253154\r\nPoids du produit4.50 g\r\nCouleur(s)Blanc, Bleu\r\nType de pierre fineTopaze bleue traitée\r\nType de pierre de synt'),
(671, 'Collier  argent 925 46 cm\r\n', 2, '28.000', 'produits/colfemme/7.png', 'CARACTÉRISTIQUES COLLIER\r\nCOLLIER argent 925, maille fantaisie, pendentif 3 anneaux entrelacés. Fermoir mousqueton. Longueur 46 cm avec un anneau de raccourcissement à 42 cm. Gravure 15 caractères maximum par disque.\r\n\r\nMarqueMATY\r\nGenreFemme\r\nRéférence02'),
(672, 'Collier argent 925\r\n', 2, '17.000', 'produits/colfemme/8.png', 'CARACTÉRISTIQUES COLLIER\r\nCOLLIER argent 925, pampilles. Fermoir mousqueton. Long. 46 cm.\r\n\r\nMarqueMATY\r\nGenreFemme\r\nRéférence0256994\r\nPoids du produit9.00 g\r\nCouleur(s)Blanc\r\nMatièreArgent 925\r\nPoids moyen Argent9.00 grammes\r\nType de collierCollier\r\nType'),
(673, 'Collier argent 925\r\n\r\n', 2, '35.000', 'produits/colfemme/9.png', 'CARACTÉRISTIQUES COLLIER\r\nCOLLIER en argent 925. Fermoir mousqueton. Longueur 45 cm avec anneau de raccourcissement à 42 cm.\r\n\r\nMarqueMATY\r\nGenreFemme\r\nRéférence0652342\r\nPoids du produit2.49 g\r\nCouleur(s)Blanc\r\nMatièreArgent 925\r\nPoids moyen Argent2.49 gr'),
(674, 'Collier argent améthyste\r\n', 2, '35.000', 'produits/colfemme/10.png', 'CARACTÉRISTIQUES COLLIER\r\nCOLLIER argent 925, pendentif  améthyste et zirconias.  Longueur 45 cm.\r\n\r\nMarqueMATY\r\nGenreFemme\r\nRéférence0126209\r\nPoids du produit4.10 g\r\nCouleur(s)Blanc, Violet\r\nType de pierre fineAméthyste\r\nType de pierre de synthèseOxyde d'),
(675, 'Collier argent 925\r\n\r\n', 2, '55.000', 'produits/colfemme/11.png', 'CARACTÉRISTIQUES COLLIER\r\nCOLLIER argent 925, filigrane. Fermoir mousqueton. Longueur 45 cm.\r\n\r\nMarqueMATY\r\nGenreFemme\r\nRéférence0669814\r\nPoids du produit3.60 g\r\nCouleur(s)Blanc\r\nMatièreArgent 925\r\nPoids moyen Argent3.60 grammes\r\nType de collierCollier\r\nT'),
(676, 'Collier plaqué or 45 cm\r\n', 2, '25.000', 'produits/colfemme/12.png', 'CARACTÉRISTIQUES COLLIER\r\nCOLLIER plaqué or boule. Fermoir mousqueton. Long. 45 cm.\r\n\r\nMarqueMATY\r\nGenreFemme\r\nRéférence0469912\r\nCouleur(s)Jaune\r\nMatièrePlaqué or jaune\r\nType de collierCollier\r\nType de fermoirMousqueton\r\nLongueur de la chaîne45 cm\r\nType d');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `nomc` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `sujet` varchar(100) NOT NULL,
  `msg` varchar(100) NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`nomc`, `email`, `sujet`, `msg`) VALUES
('ddazdaz', 'dazdazdaz@aaa.a', 'dazdaz', 'dazdazdazdazdazdazdazdaz'),
('aaa', 'aaa@gmail.com', 'aaa', 'aaaa');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `timestamp` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `timestamp`) VALUES
(23, 'ahmedachour@gmail.com', '$2y$10$pqIsXVrGFfkY6D1XR5heTOzvasA/W5b58X9dzad4bQ1npSoLlBLtm', '2021-02-08 10:56:31'),
(24, 'a@gmail.com', '$2y$10$hWx9Czv80MazyLrI0VWYm.dRtGcZdx2YZnjl2OXj18iAfyz9BRY7u', '2021-02-08 11:44:49'),
(25, 'yassin@gmail.com', '$2y$10$VhqGKLfE4DakuFXvMXZbvOksJMXiEQRmJM64rEY3JBpdVHemwMjji', '2021-02-09 20:08:48');

-- --------------------------------------------------------

--
-- Table structure for table `usersmeta`
--

CREATE TABLE `usersmeta` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `company` varchar(255) NOT NULL,
  `address1` varchar(255) NOT NULL,
  `address2` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `zip` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usersmeta`
--

INSERT INTO `usersmeta` (`id`, `uid`, `firstname`, `lastname`, `company`, `address1`, `address2`, `city`, `state`, `country`, `zip`, `mobile`) VALUES
(12, 22, 'Yassin', 'Khabthani', '', '01 Rue el Bahtari', '', 'Cité el Ghazela', 'Ariana', '', '2080', '52176848'),
(13, 24, 'a', 'a', '', 'a', '', 'a', 'a', '', '505', '98'),
(14, 25, 'yassin', 'khabthani', '', '01  Rue el bahtari', '', 'Cité el Nozha', 'Ariana', '', '2080', '52176848');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orderitems`
--
ALTER TABLE `orderitems`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ordertracking`
--
ALTER TABLE `ordertracking`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `usersmeta`
--
ALTER TABLE `usersmeta`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `orderitems`
--
ALTER TABLE `orderitems`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `ordertracking`
--
ALTER TABLE `ordertracking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=677;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `usersmeta`
--
ALTER TABLE `usersmeta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
