<?php
session_start();
require_once 'config/connect.php';
include 'inc/header.php';
//include 'mdpoublie.php';
?>



	<section>

			<div class="container ">
				<div class="row">
					<div class="col-md-12 my-5">
				<div class="row">
				<div class="col-md-6">
					<div >
						<h3>Se connecter</h3>

						<?php if(isset($_GET['message'])){
								if($_GET['message'] == 1){
						 ?><div class="alert alert-danger" role="alert"> <?php echo "Invalid Login Credentials"; ?> </div>

						 <?php } }?>
						<form  method="post" action="loginprocess.php">
							<div class="row">
									<div class="col-md-12 my-3">
										<label>Adresse E-mail</label>
										<input type="email" name="email" value="" placeholder="Entrer votre adresse E-mail"class="form-control">
									</div>
							</div>
							<div class="clearfix space20"></div>
							<div class="row">
									<div class="col-md-12 mb-3">
										<label>Mot de passe</label>
										<input type="password" name="password" value="" placeholder="Entrer votre Mot de Passe" class="form-control">
										<a href="champ.php" >Mot de passe oublié?</a>
									</div>

							</div>
							
							<div class="clearfix space20"></div>
							<div class="row">
								<div class="col-md-12 mb-5">
									 <span class="remember-box checkbox">
									<label for="rememberme">
									<input type="checkbox" id="rememberme" name="rememberme" class="mr-1">Se souvenir de moi
									</label>
									</span>
								</div>
								<div class="col-md-12 mt-2">
								
									<button type="submit" class="btn btn-md btn-dark btn-block ">Se connecter</button>
								</div>
							</div>
						</form>
					</div>
				</div>
				<div class="col-md-6">
					<div>
						<h3 class="text-center">Créer un compte</h3>
						<div class="clearfix space40"></div>
						<?php if(isset($_GET['message'])){
								if($_GET['message'] == 2){
							?><div class="alert alert-danger" role="alert"> <?php echo "Failed to Register"; ?> </div>
							<?php } } ?>
						<form class="logregform" method="post" action="registerprocess.php">
							<div class="row">
									<div class="col-md-12 my-3">
										<label>Adresse E-mail</label>
										<input type="email" name="email" placeholder ="Entrer une adresse E-mail"value="" class="form-control">
									</div>
							</div>
							<div class="clearfix space20"></div>
								<div class="form-group">
									<div class="col-md-12 mb-3">
										<label>Mot de passe</label>
										<input type="password" name="password" placeholder ="Entrer un mot de passe" value="" class="form-control">
									</div>
									<div class="col-md-12">
										<label>Confirmer votre mot de passe</label>
										<input type="password" name="passwordagain" value="" placeholder ="confirmez votre mot de passe"  class="form-control">
									</div>
							</div>
							<div class="row">
								<div class="col-md-12">
									<div class="space20"></div>
									<button type="submit" class="btn btn-dark btn-block">S'inscrire</button>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>



					</div>
				</div>
			</div>

	</section>

<?php include 'inc/footer.php' ?>
