<?php
require_once "config/connect.php";
include "inc/header.php";
?>
 <div class="titre-section titre-bracelets">
    <h2>Nos produits à prix réduit</h2>

  <a href ="#" > <i class="fas fa-plus"></i></a>
</div>

<div id="CarouselDiscount" class="carousel slide" data-ride="carousel" data-interval="0">

<div class="carousel-inner inner2">
  <div class="carousel-item active carousel-item-2">

    <div class="row row-space">

      <div class="col-lg-3">
        <div class="shadow">

        <div class="overlay">
          <img class="d-block w-100 " src="images/12.png" alt="second pic">

          
          </div>
        <div class="down-div py-3">
        <p class="title-buy text-center">
        Nom du produit
        </p>

        <p class="price-buy text-center">
        <span class="barré">25.60 DT</span> 21.50 DT
        </p>
        </div>
        </div>
      </div>

        <div class="col-lg-3">
          <div class="shadow">

        <div class="overlay">

        <img class="d-block w-100 " src="images/13.png" alt="third pic">

        
        </div>
        <div class="down-div py-3">
        <p class="title-buy text-center">
        Nom du produit
        </p>

        <p class="price-buy text-center">
        <span class="barré">25.60 DT</span> 21.50 DT
        </p>

        </div>
        </div>
      </div>

      <div class="col-lg-3">
        <div class="shadow">

        <div class="overlay">
          <img class="d-block w-100 " src="images/14.png" alt="second pic">

          
          </div>
        <div class="down-div py-3">
    <p class="title-buy text-center">
      Nom du produit
    </p>

    <p class="price-buy text-center">
    <span class="barré">25.60 DT</span> 21.50 DT
    </p>

        </div>
      </div>
      </div>
      <div class="col-lg-3">
        <div class="shadow">

        <div class="overlay">

        <img class="d-block w-100 " src="images/15.png" alt="third pic">

        
        </div>
        <div class="down-div py-3">
    <p class="title-buy text-center">
      Nom du produit
    </p>

    <p class="price-buy text-center">
    <span class="barré">25.60 DT</span> 21.50 DT
    </p>

        </div>
      </div>

      </div>
    </div>
  </div>

  <div class="carousel-item carousel-item-2">

        <div class="row row-space">

          <div class="col-lg-3">
            <div class="shadow">

            <div class="overlay">
              <img class="d-block w-100 " src="images/12.png" alt="second pic">

              
              </div>
            <div class="down-div py-3">
            <p class="title-buy text-center">
            Nom du produit
            </p>

            <p class="price-buy text-center">
            <span class="barré">25.60 DT</span> 21.50 DT
            </p>

            </div>
            </div>
          </div>

            <div class="col-lg-3">
              <div class="shadow">

            <div class="overlay">

            <img class="d-block w-100 " src="images/13.png" alt="third pic">

            
            </div>
            <div class="down-div py-3">
            <p class="title-buy text-center">
            Nom du produit
            </p>

            <p class="price-buy text-center">
            <span class="barré">25.60 DT</span> 21.50 DT
            </p>

          </div>
        </div>
            </div>

          <div class="col-lg-3">
            <div class="shadow">

            <div class="overlay">
              <img class="d-block w-100 " src="images/14.png" alt="second pic">

              
              </div>
            <div class="down-div py-3">
        <p class="title-buy text-center">
          Nom du produit
        </p>

        <p class="price-buy text-center">
        <span class="barré">25.60 DT</span> 21.50 DT
        </p>


      </div>
    </div>
          </div>
          <div class="col-lg-3">
            <div class="shadow">

            <div class="overlay">

            <img class="d-block w-100 " src="images/15.png" alt="third pic">

            
            </div>
            <div class="down-div py-3 ">
        <p class="title-buy text-center">
          Nom du produit
        </p>

        <p class="price-buy text-center">
        <span class="barré">25.60 DT</span> 21.50 DT
        </p>

            </div>

          </div>
        </div>
        </div>
  </div>
</div>
  <!-- <div class="carousel-item">
    <img class="d-block w-100" src="..." alt="Third slide">
  </div> -->


<!--<a class="carousel-control-prev" href="#CarouselDiscount" role="button" data-slide="prev">
<div class="larrow2">


  <span class="carousel-control-prev-icon" aria-hidden="true"></span>
  <span class="sr-only">Previous</span>
  </div>
</a>
<a class="carousel-control-next" href="#CarouselDiscount" role="button" data-slide="next">
<div class="rarrow2">
  <span class="carousel-control-next-icon" aria-hidden="true"></span>
  <span class="sr-only">Next</span>
    </div>
</a> -->
</div>
</section>
</div>


<?php include "inc/footer.php"; ?>
