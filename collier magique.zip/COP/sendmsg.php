<?php
ob_start();
session_start();
require_once 'config/connect.php';
$nomc= filter_var($_POST['nomc'], FILTER_SANITIZE_STRING);
$email = filter_var($_POST['email'], FILTER_SANITIZE_STRING);
$sujet = filter_var($_POST['sujet'], FILTER_SANITIZE_STRING);
$msg = filter_var($_POST['msg'], FILTER_SANITIZE_STRING);
$isql = "INSERT INTO reviews (nomc, email,sujet, msg) VALUES ('$nomc', '$email','$sujet', '$msg')";
$ures = mysqli_query($connection, $isql) or die(mysqli_error($connection));
	header('location: home.php');
  ?>
