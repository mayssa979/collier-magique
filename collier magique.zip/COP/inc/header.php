<?php require "config/connect.php"; ?> 
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Collier Magique</title>


  <!-- icons -->
  <script src="https://kit.fontawesome.com/1c3c7f18d7.js" crossorigin="anonymous"></script>

  <!-- style Bootstrap -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

<!-- google fonts -->
  <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200;300;400;500;600;700&display=swap" rel="stylesheet">

  <!-- JS bootstrap -->
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<!-- style css -->
  <link rel="stylesheet" type="text/css" href="css/styles.css">

</head>
  <body>
    <!-- first nav -->
    <header class="sticky-top">


    <nav class=" nav1 navbar-expand-lg navbar-light navbar">

      <a href="#"><img src="images/logo.png" alt="logo" class="logo" /></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#responsive" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="responsive">
      <form action = "rechercher.php" method="POST">
        <div class="input-group  form_test">
        <input type="text" name ="rechercher" class="form-control" placeholder="Rechercher" aria-label="Rechercher" aria-describedby="basic-addon2">
        <div class="input-group-append">
          <button class="btn search" type="submit"><i class="fas fa-search"></i></button>
        </div>
        </form>
      </div>

      <ul class="navbar-nav">
        <li class="nav-item">
        <a href ="cart.php"class="nav-link link1"><i class="fas fa-shopping-cart"></i> Panier
          <?php
            if (isset($_SESSION['cart'])){
                $count = count($_SESSION['cart']);
                echo "($count)";
            }else{
                echo "(0)";
            }

          ?></a>
        </li>
        <li class="nav-item">
          <a class="nav-link tiré">|</a>
        </li>
          <li class="nav-item dropdown userdrop">
          <a class="nav-link link-2 dropdown-toggle" data-toggle="dropdown" href="#"><i class="far fa-user-circle"></i> User</a>
          <ul class="dropdown-menu dropdown-menuUSER">
            <li><a class="dropdown-item dropdown-itemUSER" href="http://localhost/COP/my-account.php">Mes commandes</a></li>
            <li><a class="dropdown-item dropdown-itemUSER" href="http://localhost/COP/logout.php">Se déconnecter</a></li>
          </ul>
          </li>
        <li class="nav-item">
          <a class="nav-link tiré">|</a>
        </li>

        <li class="nav-item">
        <a href ="" class="nav-link link3 ">Français</a>
        </li>

      </ul>

      </div>
      <div class="login-pop">
        <div class="arrow-up"></div>
      <div class="login-box">
        <form method="#" action="#">


<h6 class="text-center text-white"> Se connecter</h6>
<div class="form-group mt-3">
<label for="utilisateur">Nom d'utilisateur</label>
<input type="text" class="form-control mb-3" placeholder="Veuillez entrer votre nom d'uitlisateur" aria-label="Rechercher" aria-describedby="basic-addon2">

<label for="utilisateur">Mot de passe</label>
<input type="password" class="form-control" placeholder="Veuillez entrer votre mot de passe" aria-label="Rechercher" aria-describedby="basic-addon2">
</div>
<a href="" class="mdp-oublié">Mot de passe oublié?</a>
<button type="submit" class="btn btn-dark btn-lg connect-btn btn-block mt-3"> se connecter</button>
<p class="inscri mt-3">Nouveau Membre? <a href="#" class="inscri-link">Inscrivez-vous</a></p>
        </form>
      </div>


    </div>
    </nav>


    <!-- second nav -->
      <nav class=" navbar navbar-expand-lg navbar-dark nav2">
  <button class="navbar-toggler menu2" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse justify-content-center" id="navbarNav">

    <ul class="navbar-nav">



      <li class="nav-item">
        <a class="nav-link link-2" href="home.php">ACCEUIL</a>
      </li>

      <li class="nav-item dropdown">
        <a class="nav-link link-2 dropdown-toggle" data-toggle="dropdown" href="#">COLLIERS</a>
        <ul class="dropdown-menu">
        <?php
          $catsql = "SELECT * FROM category where id=1 || id=2";
          $catres = mysqli_query($connection, $catsql);
          while($catr = mysqli_fetch_assoc($catres)){
         ?>
          <li><a class="dropdown-item" href="index.php?id=<?php echo $catr['id']; ?>"><?php echo $catr['name']; ?></a></li>
        <?php } ?>
      </ul>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link link-2 dropdown-toggle" data-toggle="dropdown" href="#">BRACELETS</a>
        <ul class="dropdown-menu">
        <?php
          $catsql = "SELECT * FROM category where id=3 || id=4";
          $catres = mysqli_query($connection, $catsql);
          while($catr = mysqli_fetch_assoc($catres)){
         ?>
          <li><a class="dropdown-item" href="index.php?id=<?php echo $catr['id']; ?>"><?php echo $catr['name']; ?></a></li>
        <?php } ?>
      </ul>
      </li>




      <li class="nav-item">
        <a class="nav-link link-2" href="contact.php">CONTACT</a>
      </li>

      <li class="nav-item">
        <a class="nav-link link-2-1" href="promo.php">PROMOS</a>
      </li>

    </ul>
  </div>
</nav>
</header>
