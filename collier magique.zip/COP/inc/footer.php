<!-- first footer -->
<footer>
  <div class="logo-f">

        <img  class="logo-footer"src="images/logo white.png" alt="logo-footer"><br />
        <div class="icon-f">
          <a href="#" class="icon-link"><i class="fab fa-facebook-square"></i></a>
          <a href="#" class="icon-link"><i class="fab fa-twitter-square"></i></a>
        <a href="#" class="icon-link"> <i class="fab fa-google-plus-square"></i></a>
        </div>
      </div>

<ul class="ul-footer" style="list-style-type:none;">
  <li class="li-header">PAGES PRINCPALES</li></a>
  <a href="http://localhost/COP/contact.php" class="link-footer"><li class="li-footer">Contact us</li></a>
  <a href="http://localhost/COP/promo.php" class="link-footer"><li class="li-footer">Promos</li></a>
  <a href="http://localhost/COP/home.php" class="link-footer"><li class="li-footer">Acceuil</li></a>
</ul>

      <ul class="ul-footer" style="list-style-type:none;">
      <li class="li-header">Mon compte</li></a>
        <a href="http://localhost/COP/my-account.php" class="link-footer"><li class="li-footer">Mes commandes</li></a>
        <a href="http://localhost/COP/logout.php" class="link-footer"><li class="li-footer">Se déconnecter</li></a>
      </ul>

      <ul class="ul-footer" style="list-style-type:none;">
      <li class="li-header">CATEGORIES</li></a>
        <a href="#" class="link-footer"><li class="li-footer">Colliers</li></a>
        <a href="#" class="link-footer"><li class="li-footer">Bracelets</li></a>

      </ul>
      <ul class="ul-footer" style="list-style-type:none;">
        <a class="link-footer"><li class="li-header">CONTACT</li></a>
        <a href="http://localhost/COP/contact.php" class="link-footer"><li class="li-footer">Contactez-nous</li></a>
    </ul>
  </div>
</footer>
<footer class="sub-footer">
  <p>
    © 2021. All Rights Reserved.
    <div class="icons-subf">
  <i class="fas fa-shield-alt"></i>
      <i class="fab fa-cc-mastercard"></i>

        <i class="fab fa-cc-visa"></i>
    </div>
  </p>
</footer>


  </body>
</html>
