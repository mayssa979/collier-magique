<?php
ob_start();
session_start();
require_once 'config/connect.php';
include 'inc/header.php';
if(isset($_GET['id']) & !empty($_GET['id'])){
	$id = $_GET['id'];
	$prodsql = "SELECT * FROM products WHERE id=$id";
	$prodres = mysqli_query($connection, $prodsql);
	$prodr = mysqli_fetch_assoc($prodres);
}else{
	header('location: index.php');
}
if (isset($_SESSION['customerid'])){
  $uid = $_SESSION['customerid'];
}
else $uid=1;

//$uid = $_SESSION['customerid'];
if(isset($_POST) & !empty($_POST)){

	$review = filter_var($_POST['review'], FILTER_SANITIZE_STRING);

	$revsql = "INSERT INTO reviews (pid, uid, review) VALUES ($id, $uid, '$review')";
	$revres = mysqli_query($connection, $revsql);
	if($revres){
		$smsg = "Review Submitted Successfully";
	}else{
		$fmsg = "Failed to Submit Review";
	}
}
 ?>










<section class="collierH">

<div class="row">

  <div class="col-1">
    <div class="col-12 thumbnail-mini">
      <img class="d-block w-100 " src="<?php echo $prodr['thumb']; ?>" alt="second pic">

    </div>

  </div>
  <div class="col-6 thumbnail-large">
    <img class="d-block w-100 " src="<?php echo $prodr['thumb']; ?>" alt="second pic">
  </div>
  <div class="col-5 mt-5">

<h3><?php echo $prodr['name']; ?></h3>
<p class="mb-0">
  Nisl, do fames, consequat adipisicing. Recusandae platea neque
</p>
<p class="suite2"><a href="#nogo" onclick="document.getElementById('lirelasuite').style.display = 'block'; this.style.display = 'none';">Lire la suite</a></p>
<p id="lirelasuite" style="display:none;">
article tendance 2021 unique seulement chez collier Magique .</p>
<h4 class="my-3"><?php echo $prodr['price']; ?> DT</h4>

<form method="get" action="addtocart.php">
<div class="form">
  <span>Quantité: </span>
    <input type="hidden" name="id" value="<?php echo $prodr['id']; ?>">
    <input type="text" class="form-control d-inline mx-1" style="width:50px;" name="quant" placeholder="1">
    <input class="btn btn-dark" style="width:125.89px;" type="submit" value="Ajouter au panier">
</div>
</form>


<h5 class="mt-4">Details du produit</h5>
<p class="text-justify" style="font-size:12px;">
  <?php echo $prodr['description']; ?>
</p>
<div>
  <h5 class="d-inline">Categories: </h5> <span>
  <?php
  $prodcatsql = "SELECT * FROM category WHERE id={$prodr['catid']}";
  $prodcatres = mysqli_query($connection, $prodcatsql);
  $prodcatr = mysqli_fetch_assoc($prodcatres);
  ?>
	<?php echo $prodcatr['name']; ?> </span><br>
</div>
</div>
</div>
</section>

<section class="discount">
	<div class="titre-section titre-bracelets">
	<h2> produits similaires</h2>
</div>



<div id="CarouselDiscount" class="carousel slide" data-ride="carousel" data-interval="0">

<div class="carousel-inner inner2">
  <div class="carousel-item active carousel-item-2">

    <div class="row row-space">

      <div class="col-lg-3">
        <div class="overlay">
          <img class="d-block w-100 " src="images/12.png" alt="second pic">

          
          </div>
        <div class="down-div">
        <p class="title-buy text-center">
        NOM DU PRODUIT
        </p>

				<p class="price-buy text-center">
				<span class="barré">25.60 DT</span> 21.50 DT
				</p>
        </div>
        </div>

        <div class="col-lg-3">
        <div class="overlay">

        <img class="d-block w-100 " src="images/13.png" alt="third pic">

       
        </div>
        <div class="down-div">
        <p class="title-buy text-center">
        NOM DU PRODUIT
        </p>

				<p class="price-buy text-center">
				<span class="barré">25.60 DT</span> 21.50 DT
				</p>
        </div>
        </div>

      <div class="col-lg-3">
        <div class="overlay">
          <img class="d-block w-100 " src="images/14.png" alt="second pic">

         
          </div>
        <div class="down-div">
    <p class="title-buy text-center">
      NOM DU PRODUIT
    </p>

		<p class="price-buy text-center">
		<span class="barré">25.60 DT</span> 21.50 DT
		</p>
        </div>
      </div>
      <div class="col-lg-3">
        <div class="overlay">

        <img class="d-block w-100 " src="images/15.png" alt="third pic">

        
        </div>
        <div class="down-div">
    <p class="title-buy text-center">
      NOM DU PRODUIT
    </p>

		<p class="price-buy text-center">
		<span class="barré">25.60 DT</span> 21.50 DT
		</p>
        </div>

      </div>
    </div>
  </div>

  <div class="carousel-item carousel-item-2">

        <div class="row row-space">

          <div class="col-lg-3">
            <div class="overlay">
              <img class="d-block w-100 " src="images/12.png" alt="second pic">

             
              </div>
            <div class="down-div">
            <p class="title-buy text-center">
            NOM DU PRODUIT
            </p>

						<p class="price-buy text-center">
						<span class="barré">25.60 DT</span> 21.50 DT
						</p>
            </div>
            </div>

            <div class="col-lg-3">
            <div class="overlay">

            <img class="d-block w-100 " src="images/13.png" alt="third pic">

            
            </div>
            <div class="down-div">
            <p class="title-buy text-center">
            NOM DU PRODUIT
            </p>

						<p class="price-buy text-center">
		        <span class="barré">25.60 DT</span> 21.50 DT
		        </p>
            </div>
            </div>

          <div class="col-lg-3">
            <div class="overlay">
              <img class="d-block w-100 " src="images/14.png" alt="second pic">

              
              </div>
            <div class="down-div">
        <p class="title-buy text-center">
          NOM DU PRODUIT
        </p>

				<p class="price-buy text-center">
				<span class="barré">25.60 DT</span> 21.50 DT
				</p>

      </div>
          </div>
          <div class="col-lg-3">
            <div class="overlay">

            <img class="d-block w-100 " src="images/15.png" alt="third pic">

            
            </div>
            <div class="down-div">
        <p class="title-buy text-center">
          NOM DU PRODUIT
        </p>

				<p class="price-buy text-center">
				<span class="barré">25.60 DT</span> 21.50 DT
				</p>
            </div>

          </div>
        </div>
  </div>
</div>
  <!-- <div class="carousel-item">
    <img class="d-block w-100" src="..." alt="Third slide">
  </div> -->


<a class="carousel-control-prev" href="#CarouselDiscount" role="button" data-slide="prev">
<div class="larrow2">


  <span class="carousel-control-prev-icon" aria-hidden="true"></span>
  <span class="sr-only">Previous</span>
  </div>
</a>
<a class="carousel-control-next" href="#CarouselDiscount" role="button" data-slide="next">
<div class="rarrow2">
  <span class="carousel-control-next-icon" aria-hidden="true"></span>
  <span class="sr-only">Next</span>
    </div>
</a>
</div>
</section>










<?php include "inc/footer.php"; ?>
