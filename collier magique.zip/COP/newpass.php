<?php 
require "config/connect.php";
include "inc/header.php";
//require "mdpoublie.php";
?>

<form method="POST" action="modifierpass.php" style ="margin-top:100px; margin-left:60px;height:300px;">
<h3>Nouveau Mot De Passe </h3>
<label for ="email" >Entrer votre Email</label><br>
<input type="email" name="email" style="width:250px;"><br>
<label for ="password" >Entrer votre Nouveau Mot De Passe</label><br>
<input type="password" name="password" style="width:250px;"><br>
<label for ="password" >Confirmer votre Mot De Passe</label><br>
<input type="password" name="password" style="width:250px;"><br>
<button type="submit" style="background-color:grey;color:white;margin-top:10px;width:250px;">Envoyer</button>
</form>
<br><br>

<?php 


require "inc/footer.php"; ?>