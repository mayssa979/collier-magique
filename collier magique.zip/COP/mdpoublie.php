<meta charset="UTF-8">
<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
    //Import PHPMailer classes into the global namespace
//These must be at the top of your script, not inside a function
require 'vendor/phpmailer/phpmailer/src/Exception.php';
require 'vendor/phpmailer/phpmailer/src/PHPMailer.php';
require 'vendor/phpmailer/phpmailer/src/SMTP.php';

//Load Composer's autoloader
require 'vendor/autoload.php';
//require "login.php";
//Instantiation and passing `true` enables exceptions
$mail = new PHPMailer(true);

try {
    //Server settings
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->SMTPDebug = 1;                      //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.sendgrid.net';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'apikey';;                     //SMTP username
    $mail->Password   = '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';                               //SMTP password
    $mail->SMTPSecure = 'tls';         //Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
    $mail->Port       = 587;                                    //TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above
    
    $email=$_POST['email'];
    //Recipients
    $mail->setFrom('semah.bader@esprit.tn', 'collier magique');
    $mail->addAddress($email);     //Add a recipient
    $mail->addReplyTo($_POST['email'], 'Information');


    $x=rand(1000,9999);
    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = '[ Mot de passe oublie ]';
    $mail->Body    = 'ton code est :'.$x.'<br>'.'cliquer sur ce bouton		<br />		<br />
    <button class="btn btn-primary">
       <a href="http://localhost/COP/newpass.php">Nouveau mot de passe</a>
    </button>		<br />		<br />';
    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    $mail->send();
    echo 'un message de réinisialisation a été envoyé';
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}

?>
        