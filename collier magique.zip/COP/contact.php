<?php
session_start();
require_once 'config/connect.php';
include 'inc/header.php';
?>
<section class="contact-Section">

  <p class="link-adress">
</p>
<h2>Contactez-nous</h2>

<div class="div-contact">
  <div class="row">
    <div class="col-7 contact-face2">
      <img class="d-block w-100 " src="images/18.png" alt="second pic">


  </div>
  <div class="col-5 contact-inputs">
<form method="post" action="sendmsg.php">
<div class="form-group">
  <label>Nom Complet</label>
  <input  name="nomc"type="text" class="form-control" id="NomC" placeholder="Veuillez entrer votre Nom complet" required>
</div>
<div class="form-group">
  <label>Email</label>
  <input name="email" type="email" class="form-control" id="email" placeholder="Veuillez entrer votre email" required>
</div>
<div class="form-group">
  <label>Sujet</label>
  <input name="sujet" type="text" class="form-control" id="sujet" placeholder="Veuillez préciser le sujet" required>
</div>
<div class="form-group">
  <label>Message</label>
  <textarea name="msg" class="form-control" id="message" placeholder="Dites nous ce que vous voulez " rows="3" required></textarea>
</div>
<button type="submit" class="btn btn-dark btn-block">Envoyer</button>
</a>
</form>

</div>

</div>
</section>


<?php include 'inc/footer.php' ?>
