<?php
session_start();
require_once 'config/connect.php';
include 'inc/header.php';
include 'admin/connect3.php';
?>
<div class="overlay2">
<?php 
  $results_per_page = 10;

?>
  <?php
    $sql = "SELECT * FROM products order by price";
    if(isset($_GET['id']) & !empty($_GET['id'])){
      $id = $_GET['id'];
      $sql .= " WHERE catid=$id";
    }


    $res = mysqli_query($connection, $sql);
    $number_of_results = mysqli_num_rows($res);
    $number_of_pages = ceil($number_of_results/$results_per_page);
    if(!isset($_GET['id'])){
    if (!isset($_GET['page'])) {
      $page = 1;
    } else {
      $page = $_GET['page'];
    }
    $this_page_first_result = ($page-1)*$results_per_page;
  }
  ?>
  <?php if (($id==3) || ($id==4)) {
echo "<img class=\"d-block w-100 \" src=\"images/braceletheader.png\" alt=\"First slide\">";
}
else if (($id==1) || ($id==2))

{
  echo "<img class=\"d-block w-100 \" src=\"images/collierheader.png\" alt=\"First slide\">";
}
?>

<div class="text-overlay2">
  <?php if (($id==3) || ($id==4)) {
echo "  <h2>Bracelets</h2>";
}
else if (($id==1) || ($id==2))

{
  echo "  <h2>Colliers et Pendentifs</h2>";
}
?>
<p class="text-small">

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent iaculis leo vitae libero lacinia laoreet. Mauris at nunc odio. Curabitur vitae posuere eros. Suspendisse at nibh diam</p>

</div>

</div>


<section class="collierH">
  <p class="link-adress">
  </p>
  <?php if (($id==3) || ($id==4)) {
  echo "  <h2>Bracelets</h2>";
  }
  else if (($id==1) || ($id==2))

  {
  echo "  <h2>Colliers</h2>";
  }
  ?>
  <form class="mt-2">
    <div class="row">


  <span class="filtre col-1 p-0 pt-2">Filtrer par</span>

      <select class="form-control col-2 selectcustom" id="metaux">
            <option>metaux</option>
            <option>argent</option>
            <option>or</option>
            <option>platinum</option>
            <option>crystal</option>
            <option>Titanium</option>
          </select>
          <select class="form-control col-2 selectcustom" id="prix">
                <option>Prix</option>
                <option a href="tric.php">Croissant</a></option>
                <option>Decroissant</option>
              </select>

  <div class="col-4">

  </div>
  <span class="col-1 filtre p-0 pt-2">Trier par:</span>
  <select class="form-control col-2 selectcustom" id="recommand">
        <option>Recommandation</option>
        <option>Croissant</option>
        <option>Decroissant</option>
      </select>
      </div>
  </form>
  
<div class="row py-5">
    <div class="container">
      <div class="row">
      <?php 
      if(!isset($_GET['id'])){
$sql='SELECT * FROM products order by price LIMIT ' . $this_page_first_result . ',' .  $results_per_page;
$result = mysqli_query($connection, $sql);}

#while($row = mysqli_fetch_array($result)) {
#  echo $row['id'] . ' ' . $row['name']. '<br>';
#}

// display the links to the pages


?>

<?php
if (!isset($_GET['id'])) {
 while($r = mysqli_fetch_assoc($result)){ ?>

            <div class="col-lg-3 produitdiv">
              <div class="shadow">

              <div class="overlay">
              <a href="single.php?id=<?php echo $r['id']; ?>">
                 <img class="d-block w-100 prod-pic" src="<?php echo $r['thumb']; ?>" alt="second pic">
              </a>
                
                </div>



                <div class="down-div">
            <p class="title-buy text-center">
              <?php echo $r['name']; ?>            </p>
            <p class="price-buy text-center">
              <?php echo $r['price']; ?> DT
            </p>
            
            <a href="addtocart.php?id=<?php echo $r['id']; ?>" class="checkoutlink">
              <button type="button" class="btn  btn-block my-2 btn-color ">Ajouter au panier</button>
              
            </a>
            
           
             
                </div>
</div>


        </div>
            <?php  }}
            else 

            while($r = mysqli_fetch_assoc($res)){ ?>

            <div class="col-lg-3 produitdiv">
              <div class="shadow">

              <div class="overlay">
              <a href="single.php?id=<?php echo $r['id']; ?>">
                 <img class="d-block w-100 prod-pic" src="<?php echo $r['thumb']; ?>" alt="second pic">
              </a>
                
                </div>



                <div class="down-div">
            <p class="title-buy text-center">
              <?php echo $r['name']; ?>            </p>
            <p class="price-buy text-center">
              <?php echo $r['price']; ?> DT
            </p>
            
            <a href="addtocart.php?id=<?php echo $r['id']; ?>" class="checkoutlink">
              <button type="button" class="btn  btn-block my-2 btn-color ">Ajouter au panier</button>
              
            </a>
            
           
             
                </div>
</div>


        </div>
        <?php } ?>
            
            


        </div>
      </div>

      <?php 
      #for ($page=1;$page<=$number_of_pages;$page++) {
 # echo '<a href="index.php?page=' . $page . '">' . $page . '</a> ';
#}
if(!isset($_GET['id'])){

if($page>1)
                {
                    echo "<a href='index.php?page=".($page-1)."' class='btn btn-danger'>Previous</a>";
                }

                
                for($i=1;$i<$number_of_pages;$i++)
                {
                    echo "<a href='index.php?page=".$i."' class='btn btn-primary'>$i</a>";
                }

                if($i>$page)
                {
                    echo "<a href='index.php?page=".($page+1)."' class='btn btn-danger'>Next</a>";
                } }
 ?>
</section>

<?php
include 'inc/footer.php';
?>